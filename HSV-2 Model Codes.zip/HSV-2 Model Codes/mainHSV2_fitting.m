%%%Cost function
function Cost=mainHSV2_fitting(vector_fit,tmin,tmax,na,nr,n_stage,fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,pwlaw,Phi_male,Phi_female,resM,resF,PopulationSizeMale,PopulationSizeFemale,DataAllPR,PooledPrevalence,declineData,LowerYear,UpperYear,m,CI)

%% initialization of parameters
q=vector_fit(1)*10;
r0=vector_fit(2);

if m==3
%%%Assuming constant rho in case of EMRO
D0=1;
alphaZ= 0;
YearW=0;
else
D0= vector_fit(3);
alphaZ= vector_fit(4);
YearW= vector_fit(5)*10^(4);    
end

init_prev_male=vector_fit(6);
init_prev_female=vector_fit(7);
AnchIR=vector_fit(8);
AnchHR=vector_fit(9);
%% Time Span and Initial Condition
dt=0.5;
tspan=tmin:dt:tmax;

S_m0=zeros(na,nr);
IA1_m0=zeros(na,nr);
IS1_m0=zeros(na,nr);

S_f0=zeros(na,nr);
IA1_f0=zeros(na,nr);
IS1_f0=zeros(na,nr);

Y0=zeros(2*n_stage*na*nr,1);

for a=4:na    
    IA1_m0(a,:)=(1-fs)*init_prev_male*PopulationSizeMale(a,:);
    IS1_m0(a,:)=fs*init_prev_male*PopulationSizeMale(a,:);
    
    IA1_f0(a,:)=(1-fs)*init_prev_female*PopulationSizeFemale(a,:);
    IS1_f0(a,:)=fs*init_prev_female*PopulationSizeFemale(a,:);
end
for a=1:na
    S_m0(a,:)=PopulationSizeMale(a,:)-IA1_m0(a,:)-IS1_m0(a,:);
    S_f0(a,:)=PopulationSizeFemale(a,:)-IA1_f0(a,:)-IS1_f0(a,:);
end

for a=1:na
    Y0(nr*(a-1)+1:nr*a)=S_m0(a,:);
    Y0(100+nr*(a-1)+1:100+nr*a)=IA1_m0(a,:);
    Y0(800+nr*(a-1)+1:800+nr*a)=IS1_m0(a,:);
    
    Y0(1500+nr*(a-1)+1:1500+nr*a)=S_f0(a,:);
    Y0(1600+nr*(a-1)+1:1600+nr*a)=IA1_f0(a,:);
    Y0(2300+nr*(a-1)+1:2300+nr*a)=IS1_f0(a,:);
end
%% Solutions

[T,Y]=ode15s(@HSV2model_Fun, tspan,Y0, [], na,nr,n_stage,fs,fGUD,pwlaw,Phi_male,Phi_female,q,alphaZ,YearW,r0,D0,resM,resF,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A);

S_M=zeros(length(T),na);
IA1_M=zeros(length(T),na);
IA2_M=zeros(length(T),na);
IA2R_M=zeros(length(T),na);
IA3_M=zeros(length(T),na);
IA3R_M=zeros(length(T),na);
IA4_M=zeros(length(T),na);
IA4R_M=zeros(length(T),na);
IS1_M=zeros(length(T),na);
IS2_M=zeros(length(T),na);
IS2R_M=zeros(length(T),na);
IS3_M=zeros(length(T),na);
IS3R_M=zeros(length(T),na);
IS4_M=zeros(length(T),na);
IS4R_M=zeros(length(T),na);

S_F=zeros(length(T),na);
IA1_F=zeros(length(T),na);
IA2_F=zeros(length(T),na);
IA2R_F=zeros(length(T),na);
IA3_F=zeros(length(T),na);
IA3R_F=zeros(length(T),na);
IA4_F=zeros(length(T),na);
IA4R_F=zeros(length(T),na);
IS1_F=zeros(length(T),na);
IS2_F=zeros(length(T),na);
IS2R_F=zeros(length(T),na);
IS3_F=zeros(length(T),na);
IS3R_F=zeros(length(T),na);
IS4_F=zeros(length(T),na);
IS4R_F=zeros(length(T),na);

for a=1:na
    S_M(:,a)=sum(Y(:,nr*(a-1)+1:nr*a),2);
    IA1_M(:,a)=sum(Y(:,100+nr*(a-1)+1:100+nr*a),2);
    IA2_M(:,a)=sum(Y(:,200+nr*(a-1)+1:200+nr*a),2);
    IA2R_M(:,a)=sum(Y(:,300+nr*(a-1)+1:300+nr*a),2);
    IA3_M(:,a)=sum(Y(:,400+nr*(a-1)+1:400+nr*a),2);
    IA3R_M(:,a)=sum(Y(:,500+nr*(a-1)+1:500+nr*a),2);
    IA4_M(:,a)=sum(Y(:,600+nr*(a-1)+1:600+nr*a),2);
    IA4R_M(:,a)=sum(Y(:,700+nr*(a-1)+1:700+nr*a),2);
    IS1_M(:,a)=sum(Y(:,800+nr*(a-1)+1:800+nr*a),2);
    IS2_M(:,a)=sum(Y(:,900+nr*(a-1)+1:900+nr*a),2);
    IS2R_M(:,a)=sum(Y(:,1000+nr*(a-1)+1:1000+nr*a),2);
    IS3_M(:,a)=sum(Y(:,1100+nr*(a-1)+1:1100+nr*a),2);
    IS3R_M(:,a)=sum(Y(:,1200+nr*(a-1)+1:1200+nr*a),2);
    IS4_M(:,a)=sum(Y(:,1300+nr*(a-1)+1:1300+nr*a),2);
    IS4R_M(:,a)=sum(Y(:,1400+nr*(a-1)+1:1400+nr*a),2);
    S_F(:,a)=sum(Y(:,1500+nr*(a-1)+1:1500+nr*a),2);
    IA1_F(:,a)=sum(Y(:,1600+nr*(a-1)+1:1600+nr*a),2);
    IA2_F(:,a)=sum(Y(:,1700+nr*(a-1)+1:1700+nr*a),2);
    IA2R_F(:,a)=sum(Y(:,1800+nr*(a-1)+1:1800+nr*a),2);
    IA3_F(:,a)=sum(Y(:,1900+nr*(a-1)+1:1900+nr*a),2);
    IA3R_F(:,a)=sum(Y(:,2000+nr*(a-1)+1:2000+nr*a),2);
    IA4_F(:,a)=sum(Y(:,2100+nr*(a-1)+1:2100+nr*a),2);
    IA4R_F(:,a)=sum(Y(:,2200+nr*(a-1)+1:2200+nr*a),2);
    IS1_F(:,a)=sum(Y(:,2300+nr*(a-1)+1:2300+nr*a),2);
    IS2_F(:,a)=sum(Y(:,2400+nr*(a-1)+1:2400+nr*a),2);
    IS2R_F(:,a)=sum(Y(:,2500+nr*(a-1)+1:2500+nr*a),2);
    IS3_F(:,a)=sum(Y(:,2600+nr*(a-1)+1:2600+nr*a),2);
    IS3R_F(:,a)=sum(Y(:,2700+nr*(a-1)+1:2700+nr*a),2);
    IS4_F(:,a)=sum(Y(:,2800+nr*(a-1)+1:2800+nr*a),2);
    IS4R_F(:,a) =sum(Y(:,2900+nr*(a-1)+1:2900+nr*a),2);
end
%% Calculations of Indicators

Prevelance_MALE_15_49=zeros(length(T),na);
Prevelance_FEMALE_15_49=zeros(length(T),na);
Prevelance_15_49=zeros(length(T),na);

Infected_Males=IA1_M+IA2_M+IA2R_M+IA3_M+IA3R_M+IA4_M+IA4R_M+IS1_M+IS2_M+IS2R_M+IS3_M+IS3R_M+IS4_M+IS4R_M;
Infected_Females=IA1_F+IA2_F+IA2R_F+IA3_F+IA3R_F+IA4_F+IA4R_F+IS1_F+IS2_F+IS2R_F+IS3_F+IS3R_F+IS4_F+IS4R_F;
Number_Males=S_M+Infected_Males;
Number_Females=S_F+Infected_Females;

for t1=1:length(T)
    for a=1:na
        Prevelance_MALE_15_49(t1,a)=100*(Infected_Males(t1,a))/((Number_Males(t1,a)));
        Prevelance_FEMALE_15_49(t1,a)=100*(Infected_Females(t1,a))/((Number_Females(t1,a))); 
        Prevelance_15_49(t1,a)=100*(Infected_Males(t1,a)+Infected_Females(t1,a))/(Number_Males(t1,a)+Number_Females(t1,a));
    end
end

for t1=1:length(T)
    Prevelance_MALE_15_49_All(t1)=100*sum(Infected_Males(t1,4:10))/(sum(Number_Males(t1,4:10)));
    Prevelance_FEMALE_15_49_All(t1)=100*sum(Infected_Females(t1,4:10))/(sum(Number_Females(t1,4:10))); 
    Prevelance_15_49_All(t1)=100*sum(Infected_Males(t1,4:10)+Infected_Females(t1,4:10))/sum(Number_Males(t1,4:10)+Number_Females(t1,4:10));
end
  
%%
CostF=0;
CostM=0;
CostFIR=0;
CostMIR=0;
CostFHR=0;
CostMHR=0;

%General Populations

if m==4 %EURO
   for a=1:na-1
        for n=1:length(DataAllPR{1,a,1}(:,1)) %1 is Female, 1 is General populations
            if DataAllPR{1,a,1}(n,2)<45 %%Exclude outlier
            CostF=CostF+DataAllPR{1,a,1}(n,4).*(Prevelance_FEMALE_15_49(round((DataAllPR{1,a,1}(n,1)-tmin)*2+1),a)-DataAllPR{1,a,1}(n,2))^2;
            end
        end
   end
else
   for a=1:na-1
        for n=1:length(DataAllPR{1,a,1}(:,1)) %1 is Female, 1 is General populations
            if isnan(DataAllPR{1,a,1}(n,2))== 0 
            CostF=CostF+DataAllPR{1,a,1}(n,4).*(Prevelance_FEMALE_15_49(round((DataAllPR{1,a,1}(n,1)-tmin)*2+1),a)-DataAllPR{1,a,1}(n,2))^2;
            end
        end
   end
end

for a=1:na-1
for n=1:length(DataAllPR{2,a,1}(:,1)) %2 is male, 1 is General populations
    if isnan(DataAllPR{2,a,1}(n,2))== 0 
    CostM=CostM+DataAllPR{2,a,1}(n,4).*(Prevelance_MALE_15_49(round((DataAllPR{2,a,1}(n,1)-tmin)*2+1),a)-DataAllPR{2,a,1}(n,2))^2;
    end
end
end

% if m<7
    %Intermediate Risk Populations
    for a=1:na-1
    for n=1:length(DataAllPR{1,a,2}(:,1)) 
        CostFIR=CostFIR+DataAllPR{1,a,2}(n,4).*(Prevelance_FEMALE_15_49(round((DataAllPR{1,a,2}(n,1)-tmin)*2+1),a)-AnchIR.*DataAllPR{1,a,2}(n,2))^2;
    end
    end

    for a=1:na-1
    for n=1:length(DataAllPR{2,a,2}(:,1)) 
        CostMIR=CostMIR+DataAllPR{2,a,2}(n,4).*(Prevelance_MALE_15_49(round((DataAllPR{2,a,2}(n,1)-tmin)*2+1),a)-AnchIR.*DataAllPR{2,a,2}(n,2))^2;
    end
    end

    %Higher Risk Populations
    for a=1:na-1
    for n=1:length(DataAllPR{1,a,3}(:,1)) 
        CostFHR=CostFHR+DataAllPR{1,a,3}(n,4).*(Prevelance_FEMALE_15_49(round((DataAllPR{1,a,3}(n,1)-tmin)*2+1),a)-AnchHR.*DataAllPR{1,a,3}(n,2))^2;
    end
    end

    for a=1:na-1
    for n=1:length(DataAllPR{2,a,3}(:,1)) 
        CostMHR=CostMHR+DataAllPR{2,a,3}(n,4).*(Prevelance_MALE_15_49(round((DataAllPR{2,a,3}(n,1)-tmin)*2+1),a)-AnchHR.*DataAllPR{2,a,3}(n,2))^2;
    end
    end

%%%For EMRO only, the the model was additionally fitted to the prevalence ratio of women to men
%Reference Table 3 from https://pubmed.ncbi.nlm.nih.gov/36815489/
Cost_Pooled=0;
if m==3
for n=1:length(DataAllPR{1,1}(:,1))
    for a=1:na-1
    Cost_Pooled=Cost_Pooled+(Prevelance_MALE_15_49_All(round((DataAllPR{1,a,1}(n,1)-tmin)*2+1))-0.7.*Prevelance_FEMALE_15_49_All(round((DataAllPR{1,a,1}(n,1)-tmin)*2+1)))^2;
    end
end
end

Cost_USA=0;
if m==7
   Time=[1991 1999.5 2001.5 2003.5 2005.5 2007.5 2009.5 2011.5 2013.5 2015.5]; 
   if CI==1
      DataM=[17.28	12.68	12.67	12.04	13.54	12.19	11.3	11.93	8.68	8.94];
      DataF=[25.81	26.89	26.03	23.71	23.34	23.55	21.97	22.96	19.15	17.89];
   elseif CI==2 %Lower
      DataM=[14.99	9.43	9.93	9.94	10.8	9.6	    10.44	9.59	7.1	    7.05];
      DataF=[23.82	23.1	22.62	21.6	19.41	20.93	19.84	19.87	15.7	14.45];
   else
      DataM=[19.84	16.84	16.04	14.52	16.84	15.35	12.23	14.75	10.58	11.27];
      DataF=[27.92	31.04	29.77	25.95	27.8	26.38	24.27	26.36	23.14	21.94]; 
   end
   for ny=1:10
       Cost_USA=Cost_USA+(Prevelance_MALE_15_49_All(round((Time(ny)-tmin)*2+1))-DataM(ny))^2+(Prevelance_FEMALE_15_49_All(round((Time(ny)-tmin)*2+1))-DataF(ny))^2;
   end
end

Cost=1.*(CostF+CostM)+1.*(CostFIR+CostMIR+CostFHR+CostMHR)+10.*Cost_Pooled+10.*Cost_USA;

