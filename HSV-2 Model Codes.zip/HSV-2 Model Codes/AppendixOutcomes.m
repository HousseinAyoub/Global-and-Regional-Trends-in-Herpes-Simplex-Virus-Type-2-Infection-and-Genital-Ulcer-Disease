%Figure S2
%Global and Total
subplot(311)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Prevelance_15_99NL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Prevelance_15_99NU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Prevelance_15_99{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylim([0 40])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'HSV-2 prevalence in the total,';'population excluding children (%)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(312)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [IncidenceRate_15_99NL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(IncidenceRate_15_99NU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,IncidenceRate_15_99{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylabel({'HSV-2 incidence rate in the total';'population excluding children';'(per 1,000 person-years)'})
xlabel('Year')
ylim([0 20])
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(313)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Incidence_15_99NL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Incidence_15_99NU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Incidence_15_99{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Annual number of new HSV-2 infections';'in the total population excluding children';'(millions)'})
xlabel('Year')
ylim([0 50])
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)

%%Figure S3
OrderRegion=[2 1 5 4 3 6];
fname1=["Region of the Americas","African Region","Eastern Mediterranean Region","European Region","South-East Asia Region","Western Pacific Region","Global"];
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Prevelance_15_99NL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Prevelance_15_99NU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Prevelance_15_99{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)

ylim([0 max(Prevelance_15_99{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))])
xlim([1980 2050])
ylabel({'HSV-2 prevalence in the total';'population excluding children (%)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)

%%Figure S4
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [IncidenceRate_15_99NL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(IncidenceRate_15_99NU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,IncidenceRate_15_99{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)

ylim([0 max(IncidenceRate_15_99{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))])
xlim([1980 2050])
ylabel({'HSV-2 incidence rate in the total';'population excluding children';'(per 1,000 person-years)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
   
%%Figure 5
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Incidence_15_99NL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Incidence_15_99NU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Incidence_15_99{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)

ylim([0 max(Incidence_15_99{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6)
xlim([1980 2050])
ylabel({'Annual number of new HSV-2 infections';'in the total population excluding';'children (millions)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
   
   
%Figure 6_2
%Global and Total
subplot(211)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDTotalNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDTotalNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUDTotal{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylim([0 max(NbPeopleGUDTotal{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'Number of individuals in the total population,';'excluding children, experiencing at least one';'GUD episode within a year (millions)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(212)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDTotalNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDTotalNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUDTotal{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Number of GUD person-days due to HSV-2 in';'the total population excluding children (millions)'})
xlabel('Year')
ylim([0 max(TimeGUDTotal{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
set(gca, 'FontSize', 7)

%Figure 6_3
%Global and Total stratified by sex
subplot(221)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDTotalFNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDTotalFNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUDFTotal{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylim([0 max(NbPeopleGUDFTotal{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'Number of individuals in the total population,';'excluding children, experiencing at least one';'GUD episode within a year (millions)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(222)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDTotalFNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDTotalFNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUDFTotal{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Number of GUD person-days due to HSV-2 in';'the total population excluding children (millions)'})
xlabel('Year')
ylim([0 max(TimeGUDFTotal{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
set(gca, 'FontSize', 7)

subplot(223)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDTotalMNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDTotalMNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUDMTotal{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylim([0 max(NbPeopleGUDMTotal{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'Number of individuals in the total population,';'excluding children, experiencing at least one';'GUD episode within a year (millions)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(224)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDTotalMNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDTotalMNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUDMTotal{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Number of GUD person-days due to HSV-2 in';'the total population excluding children (millions)'})
xlabel('Year')
ylim([0 max(TimeGUDMTotal{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
set(gca, 'FontSize', 7)

%%Figure 7
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDNL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDNU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUD{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)

ylim([0 max(NbPeopleGUD{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6)
xlim([1980 2050])
ylabel({'Number of individuals aged 15-49 years';'with at least one episode of GUD';'due to HSV-2 (millions)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)

%%Figure 8
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDNL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDNU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUD{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)

ylim([0 max(TimeGUD{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6)
xlim([1980 2050])
ylabel({'Number of GUD person-days due to HSV-2';'among individuals aged 15-49 years';'(millions)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
   
%%Figure 9
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDTotalNL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDTotalNU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUDTotal{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)

ylim([0 max(NbPeopleGUDTotal{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6)
xlim([1980 2050])
ylabel({'Number of individuals with at';' least one episode of GUD';'due to HSV-2 (millions)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)

%%Figure 10
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDTotalNL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDTotalNU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUDTotal{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)

ylim([0 max(TimeGUDTotal{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6)
xlim([1980 2050])
ylabel({'Number of GUD person-days';'due to HSV-2 (millions)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)