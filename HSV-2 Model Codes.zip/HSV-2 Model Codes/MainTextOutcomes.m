%Figure 1
%Global and Total
subplot(311)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Prevelance_15_49NL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Prevelance_15_49NU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Prevelance_15_49{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylim([0 40])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'HSV-2 prevalence among individuals';'aged 15-49 years (%)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(312)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [IncidenceRate_15_49NL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(IncidenceRate_15_49NU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,IncidenceRate_15_49{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylabel({'HSV-2 incidence rate among';'individuals aged 15-49 years';'(per 1,000 person-years)'})
xlabel('Year')
ylim([0 20])
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(313)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Incidence_15_49NL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Incidence_15_49NU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Incidence_15_49{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Annual number of new HSV-2 infections';'among individuals aged 15-49 years';'(millions)'})
xlabel('Year')
ylim([0 50])
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)

%Figure 2
%Global and by sex
subplot(321)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Prevelance_15_49_FNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Prevelance_15_49_FNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Prevelance_15_49_F{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylim([0 40])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'HSV-2 prevalence among women';'aged 15-49 years (%)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(322)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Prevelance_15_49_MNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Prevelance_15_49_MNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Prevelance_15_49_M{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylim([0 40])
ylabel({'HSV-2 prevalence among men';'aged 15-49 years (%)'})
xlabel('Year')
set(gca, 'FontSize', 7)

subplot(323)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [IncidenceRate_15_49_FNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(IncidenceRate_15_49_FNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,IncidenceRate_15_49_F{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylabel({'HSV-2 incidence rate among';'women aged 15-49 years';'(per 1,000 person-years)'})
xlabel('Year')
ylim([0 20])
set(gca, 'FontSize', 7)
subplot(324)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [IncidenceRate_15_49_MNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(IncidenceRate_15_49_MNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,IncidenceRate_15_49_M{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)
ylabel({'HSV-2 incidence rate among';'men aged 15-49 years';'(per 1,000 person-years)'})
xlabel('Year')
ylim([0 20])
set(gca, 'FontSize', 7)

subplot(325)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Incidence_15_49_FNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Incidence_15_49_FNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Incidence_15_49_F{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Annual number of new HSV-2 infections';'among women aged 15-49 years';'(millions)'})
xlabel('Year')
ylim([0 50])
set(gca, 'FontSize', 7)
subplot(326)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Incidence_15_49_MNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Incidence_15_49_MNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Incidence_15_49_M{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Annual number of new HSV-2 infections';'among men aged 15-49 years';'(millions)'})
xlabel('Year')
ylim([0 50])
set(gca, 'FontSize', 7)

%%Figure 3
% WHO African Region.
% WHO Region of the Americas.
% WHO South-East Asia Region.
% WHO European Region.
% WHO Eastern Mediterranean Region.
% WHO Western Pacific Region.
OrderRegion=[2 1 5 4 3 6];
fname1=["Region of the Americas","African Region","Eastern Mediterranean Region","European Region","South-East Asia Region","Western Pacific Region","Global"];
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Prevelance_15_49NL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Prevelance_15_49NU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Prevelance_15_49{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)

ylim([0 max(Prevelance_15_49{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))])
xlim([1980 2050])
ylabel({'HSV-2 prevalence among individuals';'aged 15-49 years (%)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)

%%Figure 4
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [IncidenceRate_15_49NL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(IncidenceRate_15_49NU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))];
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,IncidenceRate_15_49{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'k','LineWidth',2)

ylim([0 max(IncidenceRate_15_49{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))])
xlim([1980 2050])
ylabel({'HSV-2 incidence rate among';'individuals aged 15-49 years';'(per 1,000 person-years)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
   
%%Figure 5
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [Incidence_15_49NL{m}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(Incidence_15_49NU{m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,Incidence_15_49{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)

ylim([0 max(Incidence_15_49{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6)
xlim([1980 2050])
ylabel({'Annual number of new HSV-2 infections';'among individuals aged 15-49 years';'(millions)'})
xlabel('Year')
title(fname1(m),'fontweight','bold')
set(gca, 'FontSize', 7)
end
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
   
   
%Figure 6
%Global and Total
subplot(211)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUD{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylim([0 max(NbPeopleGUD{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'Number of individuals aged 15-49 years experiencing';'at least one GUD episode within a year' ;'(millions)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(212)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUD{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Number of GUD person-days due to HSV-2';'among individuals aged 15-49 years';'(millions)'})
xlabel('Year')
ylim([0 max(TimeGUD{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
set(gca, 'FontSize', 7)


%Figure 6S (stratified by gender)
%Global and Total
subplot(221)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDFNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDFNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUDF{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylim([0 max(NbPeopleGUDF{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'Number of individuals aged 15-49 years experiencing';'at least one GUD episode within a year' ;'(millions)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(222)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDFNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDFNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUDF{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Number of GUD person-days due to HSV-2';'among individuals aged 15-49 years';'(millions)'})
xlabel('Year')
ylim([0 max(TimeGUDF{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
set(gca, 'FontSize', 7)

subplot(223)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [NbPeopleGUDMNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(NbPeopleGUDMNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,NbPeopleGUDM{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylim([0 max(NbPeopleGUDM{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
legend([p1 p11], {'Point estimate', '95% uncertainty interval'}, ...
       'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 7)
ylabel({'Number of individuals aged 15-49 years experiencing';'at least one GUD episode within a year' ;'(millions)'})
xlabel('Year')
set(gca, 'FontSize', 7)
title('Global', 'FontSize', 14)
subplot(224)
hold on
x2 = [dtt, fliplr(dtt)];
inBetween = [TimeGUDMNL{7}((1980-tmin)*2+1:(2050-tmin)*2+1) fliplr(TimeGUDMNU{7}((1980-tmin)*2+1:(2050-tmin)*2+1))]./10^6;
p11=fill(x2, inBetween, [0.8 0.8 0.8], 'EdgeColor', 'none');
p1=plot(dtt,TimeGUDM{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6,'k','LineWidth',2)
ylabel({'Number of GUD person-days due to HSV-2';'among individuals aged 15-49 years';'(millions)'})
xlabel('Year')
ylim([0 max(TimeGUDM{3,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./10^6)])
set(gca, 'FontSize', 7)


[M,I]=min(Prevelance_15_49{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1))
1980+I/2

mean(Prevelance_15_49_M{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./Prevelance_15_49_F{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1))

[M,I]=min(IncidenceRate_15_49{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1))
1980+I/2

mean(IncidenceRate_15_49_M{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1)./IncidenceRate_15_49_F{1,7}((1980-tmin)*2+1:(2050-tmin)*2+1))
