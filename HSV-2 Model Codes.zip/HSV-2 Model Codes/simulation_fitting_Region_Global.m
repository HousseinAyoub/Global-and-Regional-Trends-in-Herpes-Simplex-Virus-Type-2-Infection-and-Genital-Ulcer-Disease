% Code to simulate the model and generate the epidemiological and GUD measures
clearvars;
close all;
clc;

%%Demographic Parameters
%AMRO
resMM(:,1)=[0.0261207954133122;1946.81772633606;118.599541538751;16.4110629955483;1.09490860011076;0.515181604928620;1931.34772058403;105.329882094398];
resFF(:,1)=[0.0287475400714148;1949.42525322778;102.207330010115;19.5355361224265;0.601460757019454;0.995476239856705;1955.00343997857;80.1986285594092];
%AFRO
resMM(:,2)=[0.0353619448124214;1978.59700090851;115.525900027459;13.9945883126358;4686.69070197867;0.149130144239916;1992.23700499082;133.736583479586];
resFF(:,2)=[0.0364720525771215;1979.46342268484;115.280226268682;22.7720870935737;0.375100604553392;2.04141595004822;1978.31611414644;86.8373362610652];
%EMRO
resMM(:,3)=[0.0315662099280342;1966.51654857418;103.998286457569;14.9874071103858;19.9994443096425;0.149048141114245;2153.46322548890;185.527329502280];
resFF(:,3)=[0.0318317213356568;1968.67207734349;115.485186118526;18.7161847648276;0.690300074263781;1.01473586815891;1970.30872255856;104.264102475493];
%EURO
resMM(:,4)=[0.0184161320410699;1921.45699064487;178.140738217763;19.5834978770539;0.696229909053583;3.12081750815939;1845.78664151800;150.555555341066];
resFF(:,4)=[0.0177646236345601;1921.43289385640;163.117036367090;19.0785014448194;0.797827117325151;1.78439621438541;1870.56695093851;128.980453549646];
%SEARO
resMM(:,5)=[0.0296551469516410;1944.90019103475;111.733220976356;13.6802459757634;2925.12429175489;0.232771646704259;1919.39699854759;126.730286951399];
resFF(:,5)=[0.0294629096426427;1944.61605569149;105.954075398161;15.0768910937744;9.03211575593305;0.438381215184227;1914.07625184418;116.028091463275];
%WPRO
resMM(:,6)=[0.0261288889876588;1937.57273633265;99.9430665205198;13.0087965280581;1169.88416527640;0.247968704364275;1947.92415838816;65.1346581876220];
resFF(:,6)=[0.0261027607424591;1937.21987636965;93.4539884726257;16.0043155011080;186.491145969344;0.585821755462767;1955.00003586322;59.3970785786438];

%USA
resMM(:,7)=[0.0191534977138340;1947.69438134523;155.916656867262;16.0001490793720;8528.27270153018;0.507678928529457;1920.96949250443;101.068617778832];
resFF(:,7)=[0.0191634125264944;1949.05379141488;143.571033024922;18.8662282343921;0.906300985864953;0.687729833271473;1955.00216303519;88.4613112720918];

%Fitting parameters
load('Prevalence_Result_fit.mat','Prevalence_Result_fit')
load('Prevalence_Result_fit_Lower.mat','Prevalence_Result_fit_Lower')
load('Prevalence_Result_fit_Upper.mat','Prevalence_Result_fit_Upper')

Prevalence_Result{1}=Prevalence_Result_fit;
Prevalence_Result{2}=Prevalence_Result_fit_Lower;
Prevalence_Result{3}=Prevalence_Result_fit_Upper;

%%Data Extraction
%%Import dataset
%%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, Global 7)

%%Overall prevalence measures
Data=readtable('HSV-2Data_Age.xlsx','Sheet', 2);
tbl =table(Data.Name, Data.WHO_coded, Data.Gender, Data.health, Data.midpoint, Data.prevalence, Data.n, 'VariableNames', {'NameUSA', 'Region', 'Sex', 'Study_pop', 'Year','Prevalence','Sample_Size'});

%NHANES data
DataF=xlsread('NHANES_Female.xlsx', 1);
DataFL=xlsread('NHANES_Female.xlsx', 2);
DataFU=xlsread('NHANES_Female.xlsx', 3);

DataM=xlsread('NHANES_Male.xlsx', 1);
DataML=xlsread('NHANES_Male.xlsx', 2);
DataMU=xlsread('NHANES_Male.xlsx', 3);

%All_ populations
for m=1:7 %%Over each region

if m~=1    
%%%Total population size male and female
    PoulationSizeM='Malepopulationsize.xlsx';
    PopulationMale= xlsread(PoulationSizeM,m);
    PopulationMale=1000.*PopulationMale;

    PoulationSizeF='Femalepopulationsize.xlsx';
    PopulationFemale= xlsread(PoulationSizeF,m);
    PopulationFemale=1000.*PopulationFemale;    
else
    %%%Total population size male and female
    PoulationSizeM='Malepopulationsize.xlsx';
    PopulationMale1= xlsread(PoulationSizeM,m);
    PopulationMale2= xlsread(PoulationSizeM,7);
    PopulationMale=1000.*(PopulationMale1-PopulationMale2);

    PoulationSizeF='Femalepopulationsize.xlsx';
    PopulationFemale1= xlsread(PoulationSizeF,m);
    PopulationFemale2= xlsread(PoulationSizeF,7);    
    PopulationFemale=1000.*(PopulationFemale1-PopulationFemale2);  
end
%%%Extrting data
for se=1:2 %Women 1 and Men 2
for pop=1:3 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==1
Data_All_population=tbl((tbl.NameUSA ~="NHANES")&(tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
elseif m==7
Data_All_population=tbl((tbl.NameUSA =="NHANES")&(tbl.Sex ==se)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
else    
Data_All_population=tbl((tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
end
Data_All_population_YP=table(Data_All_population.Year,Data_All_population.Prevalence,Data_All_population.Sample_Size);
DataAllP{m,se,pop}=table2array(Data_All_population_YP);
DataAllP_Lower{m,se,pop}(:,1)=DataAllP{m,se,pop}(:,1);
DataAllP_Upper{m,se,pop}(:,1)=DataAllP{m,se,pop}(:,1);

DataAllP{m,se,pop}(:,4)=WeightingNoAge(DataAllP,m,se,pop);
DataAllP_Lower{m,se,pop}(:,4)=DataAllP{m,se,pop}(:,4);
DataAllP_Upper{m,se,pop}(:,4)=DataAllP{m,se,pop}(:,4);

for i=1:length(DataAllP{m,se,pop}(:,1))
    [phat,pci] = binofit(DataAllP{m,se,pop}(i,2)/100*DataAllP{m,se,pop}(i,3),DataAllP{m,se,pop}(i,3));
    DataAllP_Lower{m,se,pop}(i,2)=100.*pci(1);
    DataAllP_Upper{m,se,pop}(i,2)=100.*pci(2);
    
    DataAllP_Lower{m,se,pop}(i,3:4)=DataAllP{m,se,pop}(i,3:4);
    DataAllP_Upper{m,se,pop}(i,3:4)=DataAllP{m,se,pop}(i,3:4);
end
if m==7
   if pop==1 
       if se==1 
       DataAllP{m,se,pop}=DataF;
       DataAllP_Lower{m,se,pop}=DataFL;
       DataAllP_Upper{m,se,pop}=DataFU;
       else
       DataAllP{m,se,pop}=DataM;
       DataAllP_Lower{m,se,pop}=DataML;
       DataAllP_Upper{m,se,pop}=DataMU;
       end
   end
end
   
DataAllPR{1,se,pop}=DataAllP{m,se,pop};
DataAllPR{2,se,pop}=DataAllP_Lower{m,se,pop};
DataAllPR{3,se,pop}=DataAllP_Upper{m,se,pop};  
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%parameters related to risk
nr=5; %number of risk groups

%parameters related to age groups
na=20; %age interval of five years

n_stage=15;

%the level of risk of exposure dependent by age
a=1:na;
Phi_male=(5./(a.*sqrt(2*pi*(0.3707)^2))).*(exp((-(log(a)-1.792).^2)./(2*(0.3707)^2)));
Phi_female=(8./(a.*sqrt(2*pi*(0.3948)^2))).*(exp((-(log(a)-1.859).^2)./(2*(0.3948)^2)));

%--- power law function in level of risk of exposure
beta_law=2.8;
jj=1:5;
pwlaw=jj.^beta_law;

%%Estimated Parameters for the birth and mortality Male and Female
%Demographique Male
resM=resMM(:,m);
%Demographique female
resF=resFF(:,m);

% Distributing the population 
%PopulationSize=zeros(n_sex,na,nr);%intitialization
RiskGroupPopulationFactorsMales=[0.1307,0.6577,0.0811,0.0358,0.0947];
RiskGroupPopulationFactorsFemales=[0.1736,0.6828,0.0848,0.0299,0.0289];
PopulationSizeMale=PopulationMale(1,2:21)'*RiskGroupPopulationFactorsMales;
PopulationSizeFemale=PopulationFemale(1,2:21)'*RiskGroupPopulationFactorsFemales;

for CI=1:3
    if CI==1    
       [fs,fGUD,pi1S(CI),pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1(CI),ProportionGenitalLession2(CI),ProportionGenitalLession3(CI)] =TransitionRates(0);
    elseif CI==2
       [fs,fGUD,pi1S(CI),pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1(CI),ProportionGenitalLession2(CI),ProportionGenitalLession3(CI)] =TransitionRates(-0.3); 
    else
       [fs,fGUD,pi1S(CI),pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1(CI),ProportionGenitalLession2(CI),ProportionGenitalLession3(CI)] =TransitionRates(0.3);
    end
    
%% Estimated Parameters
q=Prevalence_Result{CI}(1,m)*10;
r0=Prevalence_Result{CI}(2,m);

if m==3
%%%Assuming constant rho in case of EMRO
D0=1;
alphaZ= 0;
YearW=0;
else
D0= Prevalence_Result{CI}(3,m);
alphaZ= Prevalence_Result{CI}(4,m);
YearW= Prevalence_Result{CI}(5,m)*10^(4); 
end


init_prev_male=Prevalence_Result{CI}(6,m);
init_prev_female=Prevalence_Result{CI}(7,m);
AnchIR=Prevalence_Result{1}(8,m);
AnchHR=Prevalence_Result{1}(9,m);

%% Time Span 
%years: These should be the same as the years used for demographic model
tmin=1750; %beginning
tmax=2050.5; %end year 
% tmax=2500.5; %end year %just for testing
dt=0.5;
tspan=tmin:dt:tmax;
for t=tmin:dt:tmax
Cf0((t-tmin)*2+1,m)=(1+alphaZ/(1+exp(((t-YearW)/D0)))).*r0;
end

S_m0=zeros(na,nr);
IA1_m0=zeros(na,nr);
IS1_m0=zeros(na,nr);

S_f0=zeros(na,nr);
IA1_f0=zeros(na,nr);
IS1_f0=zeros(na,nr);

Y0=zeros(2*n_stage*na*nr,1);

for a=4:na    
    IA1_m0(a,:)=(1-fs)*init_prev_male*PopulationSizeMale(a,:);
    IS1_m0(a,:)=fs*init_prev_male*PopulationSizeMale(a,:);
    
    IA1_f0(a,:)=(1-fs)*init_prev_female*PopulationSizeFemale(a,:);
    IS1_f0(a,:)=fs*init_prev_female*PopulationSizeFemale(a,:);
end
for a=1:na
    S_m0(a,:)=PopulationSizeMale(a,:)-IA1_m0(a,:)-IS1_m0(a,:);
    S_f0(a,:)=PopulationSizeFemale(a,:)-IA1_f0(a,:)-IS1_f0(a,:);
end

for a=1:na
    Y0(nr*(a-1)+1:nr*a)=S_m0(a,:);
    Y0(100+nr*(a-1)+1:100+nr*a)=IA1_m0(a,:);
    Y0(800+nr*(a-1)+1:800+nr*a)=IS1_m0(a,:);
    
    Y0(1500+nr*(a-1)+1:1500+nr*a)=S_f0(a,:);
    Y0(1600+nr*(a-1)+1:1600+nr*a)=IA1_f0(a,:);
    Y0(2300+nr*(a-1)+1:2300+nr*a)=IS1_f0(a,:);
end
%% Solutions to the model 
tic

[T,Y]=ode15s(@(t,y)HSV2model_Fun(t,y,na,nr,n_stage,fs,fGUD,pwlaw,Phi_male,Phi_female,q,alphaZ,YearW,r0,D0,resM,resF,pi1S(CI),pi2S,pi3S,pi1A,pi2A,pi3A), tspan,Y0);

S_M=zeros(length(T),na);
IA1_M=zeros(length(T),na);
IA2_M=zeros(length(T),na);
IA2R_M=zeros(length(T),na);
IA3_M=zeros(length(T),na);
IA3R_M=zeros(length(T),na);
IA4_M=zeros(length(T),na);
IA4R_M=zeros(length(T),na);
IS1_M=zeros(length(T),na);
IS2_M=zeros(length(T),na);
IS2R_M=zeros(length(T),na);
IS3_M=zeros(length(T),na);
IS3R_M=zeros(length(T),na);
IS4_M=zeros(length(T),na);
IS4R_M=zeros(length(T),na);

S_F=zeros(length(T),na);
IA1_F=zeros(length(T),na);
IA2_F=zeros(length(T),na);
IA2R_F=zeros(length(T),na);
IA3_F=zeros(length(T),na);
IA3R_F=zeros(length(T),na);
IA4_F=zeros(length(T),na);
IA4R_F=zeros(length(T),na);
IS1_F=zeros(length(T),na);
IS2_F=zeros(length(T),na);
IS2R_F=zeros(length(T),na);
IS3_F=zeros(length(T),na);
IS3R_F=zeros(length(T),na);
IS4_F=zeros(length(T),na);
IS4R_F=zeros(length(T),na);


for a=1:na
    S_M(:,a)=sum(Y(:,nr*(a-1)+1:nr*a),2);
    IA1_M(:,a)=sum(Y(:,100+nr*(a-1)+1:100+nr*a),2);
    IA2_M(:,a)=sum(Y(:,200+nr*(a-1)+1:200+nr*a),2);
    IA2R_M(:,a)=sum(Y(:,300+nr*(a-1)+1:300+nr*a),2);
    IA3_M(:,a)=sum(Y(:,400+nr*(a-1)+1:400+nr*a),2);
    IA3R_M(:,a)=sum(Y(:,500+nr*(a-1)+1:500+nr*a),2);
    IA4_M(:,a)=sum(Y(:,600+nr*(a-1)+1:600+nr*a),2);
    IA4R_M(:,a)=sum(Y(:,700+nr*(a-1)+1:700+nr*a),2);
    IS1_M(:,a)=sum(Y(:,800+nr*(a-1)+1:800+nr*a),2);
    IS2_M(:,a)=sum(Y(:,900+nr*(a-1)+1:900+nr*a),2);
    IS2R_M(:,a)=sum(Y(:,1000+nr*(a-1)+1:1000+nr*a),2);
    IS3_M(:,a)=sum(Y(:,1100+nr*(a-1)+1:1100+nr*a),2);
    IS3R_M(:,a)=sum(Y(:,1200+nr*(a-1)+1:1200+nr*a),2);
    IS4_M(:,a)=sum(Y(:,1300+nr*(a-1)+1:1300+nr*a),2);
    IS4R_M(:,a)=sum(Y(:,1400+nr*(a-1)+1:1400+nr*a),2);
    S_F(:,a)=sum(Y(:,1500+nr*(a-1)+1:1500+nr*a),2);
    IA1_F(:,a)=sum(Y(:,1600+nr*(a-1)+1:1600+nr*a),2);
    IA2_F(:,a)=sum(Y(:,1700+nr*(a-1)+1:1700+nr*a),2);
    IA2R_F(:,a)=sum(Y(:,1800+nr*(a-1)+1:1800+nr*a),2);
    IA3_F(:,a)=sum(Y(:,1900+nr*(a-1)+1:1900+nr*a),2);
    IA3R_F(:,a)=sum(Y(:,2000+nr*(a-1)+1:2000+nr*a),2);
    IA4_F(:,a)=sum(Y(:,2100+nr*(a-1)+1:2100+nr*a),2);
    IA4R_F(:,a)=sum(Y(:,2200+nr*(a-1)+1:2200+nr*a),2);
    IS1_F(:,a)=sum(Y(:,2300+nr*(a-1)+1:2300+nr*a),2);
    IS2_F(:,a)=sum(Y(:,2400+nr*(a-1)+1:2400+nr*a),2);
    IS2R_F(:,a)=sum(Y(:,2500+nr*(a-1)+1:2500+nr*a),2);
    IS3_F(:,a)=sum(Y(:,2600+nr*(a-1)+1:2600+nr*a),2);
    IS3R_F(:,a)=sum(Y(:,2700+nr*(a-1)+1:2700+nr*a),2);
    IS4_F(:,a)=sum(Y(:,2800+nr*(a-1)+1:2800+nr*a),2);
    IS4R_F(:,a) =sum(Y(:,2900+nr*(a-1)+1:2900+nr*a),2);
end

% Lambda_m , Lambda_f and Incidence
L_M1=zeros(length(T),na);
L_F1=zeros(length(T),na);
Incidence_Male=zeros(length(T),na);
Incidence_Female=zeros(length(T),na);

for t=1:length(T)
    [dy,L_M1(t,:),L_F1(t,:),Incidence_Male(t,:),Incidence_Female(t,:)]=HSV2model_Fun(T(t),Y(t,:), na,nr,n_stage,fs,fGUD,pwlaw,Phi_male,Phi_female,q,alphaZ,YearW,r0,D0,resM,resF,pi1S(CI),pi2S,pi3S,pi1A,pi2A,pi3A);
end
toc
%% Calculations of Indicators
Infected_S_11RF{CI,m}=(IS1_F);
Infected_S_11RM{CI,m}=(IS1_M);
Infected_S_11R{CI,m}=(IS1_M+IS1_F);

Infected_S_1RF{CI,m}=(IS2_F+IS2R_F);
Infected_S_1RM{CI,m}=(IS2_M+IS2R_M);
Infected_S_1R{CI,m}=(IS2_M+IS2R_M+IS2_F+IS2R_F);

Infected_S_2RF{CI,m}=(IS3_F+IS3R_F);
Infected_S_2RM{CI,m}=(IS3_M+IS3R_M);
Infected_S_2R{CI,m}=(IS3_M+IS3R_M+IS3_F+IS3R_F);

Infected_S_3RF{CI,m}=(IS4_F+IS4R_F);
Infected_S_3RM{CI,m}=(IS4_M+IS4R_M);
Infected_S_3R{CI,m}=(IS4_M+IS4R_M+IS4_F+IS4R_F);

Infected_MalesR{CI,m}=IA1_M+IA2_M+IA2R_M+IA3_M+IA3R_M+IA4_M+IA4R_M+IS1_M+IS2_M+IS2R_M+IS3_M+IS3R_M+IS4_M+IS4R_M;
Infected_FemalesR{CI,m}=IA1_F+IA2_F+IA2R_F+IA3_F+IA3R_F+IA4_F+IA4R_F+IS1_F+IS2_F+IS2R_F+IS3_F+IS3R_F+IS4_F+IS4R_F;
Susceptible_MalesR{CI,m}=S_M;
Susceptible_FemalesR{CI,m}=S_F;

Number_MalesR{CI,m}=S_M+Infected_MalesR{CI,m};
Number_FemalesR{CI,m}=S_F+Infected_FemalesR{CI,m};

IncidenceRF{CI,m}=Incidence_Female;
IncidenceRM{CI,m}=Incidence_Male;
IncidenceR{CI,m}=Incidence_Male+Incidence_Female;
end
end
for m=1:7 %%Over each region
    for CI=1:3
        Infected_S_11F{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_1F{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_2F{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_3F{CI,m}=zeros(length(T),na); %% Other regions
        
        Infected_S_11M{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_1M{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_2M{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_3M{CI,m}=zeros(length(T),na); %% Other regions
        
        Infected_S_11{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_1{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_2{CI,m}=zeros(length(T),na); %% Other regions
        Infected_S_3{CI,m}=zeros(length(T),na); %% Other regions

        Infected_Males{CI,m}=zeros(length(T),na); %% Other regions
        Infected_Females{CI,m}=zeros(length(T),na); %% Other regions
        Susceptible_Males{CI,m}=zeros(length(T),na); %% Other regions
        Susceptible_Females{CI,m}=zeros(length(T),na); %% Other regions

        Number_Males{CI,m}=zeros(length(T),na); %% Other regions
        Number_Females{CI,m}=zeros(length(T),na); %% Other regions
        IncidenceM{CI,m}=zeros(length(T),na); %% Other regions
        IncidenceF{CI,m}=zeros(length(T),na); %% Other regions
        Incidence{CI,m}=zeros(length(T),na); %% Other regions
    end
end


for CI=1:3
    Infected_S_11F{CI,1}=Infected_S_11RF{CI,1}+Infected_S_11RF{CI,7}; %% AMRO+USA
    Infected_S_1F{CI,1}=Infected_S_1RF{CI,1}+Infected_S_1RF{CI,7}; %% AMRO+USA
    Infected_S_2F{CI,1}=Infected_S_2RF{CI,1}+Infected_S_2RF{CI,7}; %% AMRO+USA
    Infected_S_3F{CI,1}=Infected_S_3RF{CI,1}+Infected_S_3RF{CI,7}; %% AMRO+USA
 
    Infected_S_11M{CI,1}=Infected_S_11RM{CI,1}+Infected_S_11RM{CI,7}; %% AMRO+USA
    Infected_S_1M{CI,1}=Infected_S_1RM{CI,1}+Infected_S_1RM{CI,7}; %% AMRO+USA
    Infected_S_2M{CI,1}=Infected_S_2RM{CI,1}+Infected_S_2RM{CI,7}; %% AMRO+USA
    Infected_S_3M{CI,1}=Infected_S_3RM{CI,1}+Infected_S_3RM{CI,7}; %% AMRO+USA
    
    Infected_S_11M{CI,1}=Infected_S_11RM{CI,1}+Infected_S_11RM{CI,7}; %% AMRO+USA
    Infected_S_1{CI,1}=Infected_S_1R{CI,1}+Infected_S_1R{CI,7}; %% AMRO+USA
    Infected_S_2{CI,1}=Infected_S_2R{CI,1}+Infected_S_2R{CI,7}; %% AMRO+USA
    Infected_S_3{CI,1}=Infected_S_3R{CI,1}+Infected_S_3R{CI,7}; %% AMRO+USA

    Infected_Males{CI,1}=Infected_MalesR{CI,1}+Infected_MalesR{CI,7}; %% AMRO+USA
    Infected_Females{CI,1}=Infected_FemalesR{CI,1}+Infected_FemalesR{CI,7}; %% AMRO+USA
    Susceptible_Males{CI,1}=Susceptible_MalesR{CI,1}+Susceptible_MalesR{CI,7}; %% AMRO+USA
    Susceptible_Females{CI,1}=Susceptible_FemalesR{CI,1}+Susceptible_FemalesR{CI,7}; %% AMRO+USA
    
    Number_Males{CI,1}=Number_MalesR{CI,1}+Number_MalesR{CI,7}; %% AMRO+USA
    Number_Females{CI,1}=Number_FemalesR{CI,1}+Number_FemalesR{CI,7}; %% AMRO+USA
    IncidenceM{CI,1}=IncidenceRM{CI,1}+IncidenceRM{CI,7}; %% AMRO+USA
    IncidenceF{CI,1}=IncidenceRF{CI,1}+IncidenceRF{CI,7}; %% AMRO+USA
    Incidence{CI,1}=IncidenceR{CI,1}+IncidenceR{CI,7}; %% AMRO+USA

   
    for m=2:6
        Infected_S_11F{CI,m}=Infected_S_11RF{CI,m}; %% Other regions
        Infected_S_1F{CI,m}=Infected_S_1RF{CI,m}; %% Other regions
        Infected_S_2F{CI,m}=Infected_S_2RF{CI,m}; %% Other regions
        Infected_S_3F{CI,m}=Infected_S_3RF{CI,m}; %% Other regions

        Infected_S_11M{CI,m}=Infected_S_11RM{CI,m}; %% Other regions
        Infected_S_1M{CI,m}=Infected_S_1RM{CI,m}; %% Other regions
        Infected_S_2M{CI,m}=Infected_S_2RM{CI,m}; %% Other regions
        Infected_S_3M{CI,m}=Infected_S_3RM{CI,m}; %% Other regions

        Infected_S_11{CI,m}=Infected_S_11R{CI,m}; %% Other regions
        Infected_S_1{CI,m}=Infected_S_1R{CI,m}; %% Other regions
        Infected_S_2{CI,m}=Infected_S_2R{CI,m}; %% Other regions
        Infected_S_3{CI,m}=Infected_S_3R{CI,m}; %% Other regions
        
        
        Infected_Males{CI,m}=Infected_MalesR{CI,m}; %% Other regions
        Infected_Females{CI,m}=Infected_FemalesR{CI,m}; %% Other regions
        Susceptible_Males{CI,m}=Susceptible_MalesR{CI,m}; %% Other regions
        Susceptible_Females{CI,m}=Susceptible_FemalesR{CI,m}; %% Other regions

        Number_Males{CI,m}=Number_MalesR{CI,m}; %% Other regions
        Number_Females{CI,m}=Number_FemalesR{CI,m}; %% Other regions
        IncidenceM{CI,m}=IncidenceRM{CI,m}; %% Other regions
        IncidenceF{CI,m}=IncidenceRF{CI,m}; %% Other regions
        Incidence{CI,m}=IncidenceR{CI,m}; %% Other regions
    end

    for m=1:6
        Infected_S_11F{CI,7}=Infected_S_11F{CI,7}+Infected_S_11F{CI,m}; %% Other regions
        Infected_S_1F{CI,7}=Infected_S_1F{CI,7}+Infected_S_1F{CI,m}; %% Other regions
        Infected_S_2F{CI,7}=Infected_S_2F{CI,7}+Infected_S_2F{CI,m}; %% Other regions
        Infected_S_3F{CI,7}=Infected_S_3F{CI,7}+Infected_S_3F{CI,m}; %% Other regions

        Infected_S_11M{CI,7}=Infected_S_11M{CI,7}+Infected_S_11M{CI,m}; %% Other regions
        Infected_S_1M{CI,7}=Infected_S_1M{CI,7}+Infected_S_1M{CI,m}; %% Other regions
        Infected_S_2M{CI,7}=Infected_S_2M{CI,7}+Infected_S_2M{CI,m}; %% Other regions
        Infected_S_3M{CI,7}=Infected_S_3M{CI,7}+Infected_S_3M{CI,m}; %% Other regions

        Infected_S_11{CI,7}=Infected_S_11{CI,7}+Infected_S_11{CI,m}; %% Other regions
        Infected_S_1{CI,7}=Infected_S_1{CI,7}+Infected_S_1{CI,m}; %% Other regions
        Infected_S_2{CI,7}=Infected_S_2{CI,7}+Infected_S_2{CI,m}; %% Other regions
        Infected_S_3{CI,7}=Infected_S_3{CI,7}+Infected_S_3{CI,m}; %% Other regions
        
        Infected_Males{CI,7}=Infected_Males{CI,7}+Infected_Males{CI,m}; %% Other regions
        Infected_Females{CI,7}=Infected_Females{CI,7}+Infected_Females{CI,m}; %% Other regions
        Susceptible_Males{CI,7}=Susceptible_Males{CI,7}+Susceptible_Males{CI,m}; %% Other regions
        Susceptible_Females{CI,7}=Susceptible_Females{CI,7}+Susceptible_Females{CI,m}; %% Other regions

        Number_Males{CI,7}=Number_Males{CI,7}+Number_Males{CI,m}; %% Other regions
        Number_Females{CI,7}=Number_Females{CI,7}+Number_Females{CI,m}; %% Other regions
        IncidenceM{CI,7}=IncidenceM{CI,7}+IncidenceM{CI,m}; %% Other regions 
        IncidenceF{CI,7}=IncidenceF{CI,7}+IncidenceF{CI,m}; %% Other regions 
        Incidence{CI,7}=Incidence{CI,7}+Incidence{CI,m}; %% Other regions 

    end
end
save('Infected_S_11F.mat','Infected_S_11F')
save('Infected_S_1F.mat','Infected_S_1F')
save('Infected_S_2F.mat','Infected_S_2F')
save('Infected_S_3F.mat','Infected_S_3F')

save('Infected_S_11M.mat','Infected_S_11M')
save('Infected_S_1M.mat','Infected_S_1M')
save('Infected_S_2M.mat','Infected_S_2M')
save('Infected_S_3M.mat','Infected_S_3M')

save('Infected_S_11.mat','Infected_S_11')
save('Infected_S_1.mat','Infected_S_1')
save('Infected_S_2.mat','Infected_S_2')
save('Infected_S_3.mat','Infected_S_3')

save('Infected_Males.mat','Infected_Males')
save('Infected_Females.mat','Infected_Females')
save('Susceptible_Males.mat','Susceptible_Males')
save('Susceptible_Females.mat','Susceptible_Females')
save('Number_Males.mat','Number_Males')
save('Number_Females.mat','Number_Females')
save('IncidenceM.mat','IncidenceM')
save('IncidenceF.mat','IncidenceF')
save('Incidence.mat','Incidence')

load('Infected_S_11F.mat','Infected_S_11F')
load('Infected_S_1F.mat','Infected_S_1F')
load('Infected_S_2F.mat','Infected_S_2F')
load('Infected_S_3F.mat','Infected_S_3F')

load('Infected_S_11M.mat','Infected_S_11M')
load('Infected_S_1M.mat','Infected_S_1M')
load('Infected_S_2M.mat','Infected_S_2M')
load('Infected_S_3M.mat','Infected_S_3M')

load('Infected_S_11.mat','Infected_S_11')
load('Infected_S_1.mat','Infected_S_1')
load('Infected_S_2.mat','Infected_S_2')
load('Infected_S_3.mat','Infected_S_3')

load('Infected_Males.mat','Infected_Males')
load('Infected_Females.mat','Infected_Females')
load('Susceptible_Males.mat','Susceptible_Males')
load('Susceptible_Females.mat','Susceptible_Females')
load('Number_Males.mat','Number_Males')
load('Number_Females.mat','Number_Females')
load('IncidenceM.mat','IncidenceM')
load('IncidenceF.mat','IncidenceF')
load('Incidence.mat','Incidence')

tmin=1750; %beginning
tmax=2050.5; %end year 
dt=0.5;
T=tmin:dt:tmax;

for CI=1:3
for m=1:7
%%15-49 years old
        for t1=1:length(T)
            Prevelance_15_49_F{CI,m}(t1)=100*sum(Infected_Females{CI,m}(t1,4:10))/sum(Number_Females{CI,m}(t1,4:10));
            Incidence_15_49_F{CI,m}(t1)=sum(IncidenceF{CI,m}(t1,4:10));
            IncidenceRate_15_49_F{CI,m}(t1)=1000.*sum(IncidenceF{CI,m}(t1,4:10))/sum(Susceptible_Females{CI,m}(t1,4:10)); 

            Prevelance_15_49_M{CI,m}(t1)=100*sum(Infected_Males{CI,m}(t1,4:10))/sum(Number_Males{CI,m}(t1,4:10));
            Incidence_15_49_M{CI,m}(t1)=sum(IncidenceM{CI,m}(t1,4:10));
            IncidenceRate_15_49_M{CI,m}(t1)=1000.*sum(IncidenceM{CI,m}(t1,4:10))/sum(Susceptible_Males{CI,m}(t1,4:10)); 
           
            
            Prevelance_15_49{CI,m}(t1)=100*sum(Infected_Males{CI,m}(t1,4:10)+Infected_Females{CI,m}(t1,4:10))/sum(Number_Males{CI,m}(t1,4:10)+Number_Females{CI,m}(t1,4:10));
            Incidence_15_49{CI,m}(t1)=sum(Incidence{CI,m}(t1,4:10));
            IncidenceRate_15_49{CI,m}(t1)=1000.*sum(Incidence{CI,m}(t1,4:10))/sum(Susceptible_Males{CI,m}(t1,4:10)+Susceptible_Females{CI,m}(t1,4:10)); 
        end
%%15-99 years old
        for t1=1:length(T)
            Prevelance_15_99_F{CI,m}(t1)=100*sum(Infected_Females{CI,m}(t1,4:na))/sum(Number_Females{CI,m}(t1,4:na));
            Incidence_15_99_F{CI,m}(t1)=sum(IncidenceF{CI,m}(t1,4:na));
            IncidenceRate_15_99_F{CI,m}(t1)=1000.*sum(IncidenceF{CI,m}(t1,4:na))/sum(Susceptible_Females{CI,m}(t1,4:na)); 

            Prevelance_15_99_M{CI,m}(t1)=100*sum(Infected_Males{CI,m}(t1,4:na))/sum(Number_Males{CI,m}(t1,4:na));
            Incidence_15_99_M{CI,m}(t1)=sum(IncidenceM{CI,m}(t1,4:na));
            IncidenceRate_15_99_M{CI,m}(t1)=1000.*sum(IncidenceM{CI,m}(t1,4:na))/sum(Susceptible_Males{CI,m}(t1,4:na)); 
           
            
            Prevelance_15_99{CI,m}(t1)=100*sum(Infected_Males{CI,m}(t1,4:na)+Infected_Females{CI,m}(t1,4:na))/sum(Number_Males{CI,m}(t1,4:na)+Number_Females{CI,m}(t1,4:na));
            Incidence_15_99{CI,m}(t1)=sum(Incidence{CI,m}(t1,4:na));
            IncidenceRate_15_99{CI,m}(t1)=1000.*sum(Incidence{CI,m}(t1,4:na))/sum(Susceptible_Males{CI,m}(t1,4:na)+Susceptible_Females{CI,m}(t1,4:na)); 
        end        
%%%GUD estimates
% Number of people with any GUD
NbPeopleGUDAgeF=Infected_S_11F{CI,m}+Infected_S_1F{CI,m}+...
    Infected_S_2F{CI,m}+...
    Infected_S_3F{CI,m};
NbPeopleGUDF{CI,m}=sum(NbPeopleGUDAgeF(:,4:10),2);
NbPeopleGUDFTotal{CI,m}=sum(NbPeopleGUDAgeF(:,4:na),2);

NbPeopleGUDAgeM=Infected_S_11M{CI,m}+Infected_S_1M{CI,m}+...
    Infected_S_2M{CI,m}+...
    Infected_S_3M{CI,m};
NbPeopleGUDM{CI,m}=sum(NbPeopleGUDAgeM(:,4:10),2);
NbPeopleGUDMTotal{CI,m}=sum(NbPeopleGUDAgeM(:,4:na),2);


NbPeopleGUDAge=Infected_S_11{CI,m}+Infected_S_1{CI,m}+...
    Infected_S_2{CI,m}+...
    Infected_S_3{CI,m};
NbPeopleGUD{CI,m}=sum(NbPeopleGUDAge(:,4:10),2);
NbPeopleGUDTotal{CI,m}=sum(NbPeopleGUDAge(:,4:na),2);

% Time spent GUD
TimeGUDAgeM=Infected_S_11M{CI,m}.*365./pi1S(CI)+...
    Infected_S_1M{CI,m}.*365.25.*ProportionGenitalLession1(CI)+...
    Infected_S_2M{CI,m}.*365.25.*ProportionGenitalLession2(CI)+...
    Infected_S_3M{CI,m}.*365.25.*ProportionGenitalLession3(CI);

TimeGUDAgeF=Infected_S_11F{CI,m}.*365./pi1S(CI)+...
    Infected_S_1F{CI,m}.*365.25.*ProportionGenitalLession1(CI)+...
    Infected_S_2F{CI,m}.*365.25.*ProportionGenitalLession2(CI)+...
    Infected_S_3F{CI,m}.*365.25.*ProportionGenitalLession3(CI);

TimeGUDAge=(Infected_S_11M{CI,m}+Infected_S_11F{CI,m}).*365./pi1S(CI)+...
    (Infected_S_1M{CI,m}+Infected_S_1F{CI,m}).*365.25.*ProportionGenitalLession1(CI)+...
    (Infected_S_2M{CI,m}+Infected_S_2F{CI,m}).*365.25.*ProportionGenitalLession2(CI)+...
    (Infected_S_3M{CI,m}+Infected_S_3F{CI,m}).*365.25.*ProportionGenitalLession3(CI);

TimeGUDF{CI,m}=sum(TimeGUDAgeF(:,4:10),2);
TimeGUDM{CI,m}=sum(TimeGUDAgeM(:,4:10),2);
TimeGUD{CI,m}=sum(TimeGUDAge(:,4:10),2);

TimeGUDFTotal{CI,m}=sum(TimeGUDAgeF(:,4:na),2);
TimeGUDMTotal{CI,m}=sum(TimeGUDAgeM(:,4:na),2);
TimeGUDTotal{CI,m}=sum(TimeGUDAge(:,4:na),2);
end
end

for m=1:7
    for t1=1:length(T)
        [Prevelance_15_49NL{m}(t1),Prevelance_15_49NU{m}(t1)] =CI_Sampling_Triangular(Prevelance_15_49{1,m}(t1),Prevelance_15_49{2,m}(t1),Prevelance_15_49{3,m}(t1));
        [Prevelance_15_49_FNL{m}(t1),Prevelance_15_49_FNU{m}(t1)] =CI_Sampling_Triangular(Prevelance_15_49_F{1,m}(t1),Prevelance_15_49_F{2,m}(t1),Prevelance_15_49_F{3,m}(t1));
        [Prevelance_15_49_MNL{m}(t1),Prevelance_15_49_MNU{m}(t1)] =CI_Sampling_Triangular(Prevelance_15_49_M{1,m}(t1),Prevelance_15_49_M{2,m}(t1),Prevelance_15_49_M{3,m}(t1));

        [Prevelance_15_99NL{m}(t1),Prevelance_15_99NU{m}(t1)] =CI_Sampling_Triangular(Prevelance_15_99{1,m}(t1),Prevelance_15_99{2,m}(t1),Prevelance_15_99{3,m}(t1));
        [Prevelance_15_99_FNL{m}(t1),Prevelance_15_99_FNU{m}(t1)] =CI_Sampling_Triangular(Prevelance_15_99_F{1,m}(t1),Prevelance_15_99_F{2,m}(t1),Prevelance_15_99_F{3,m}(t1));
        [Prevelance_15_99_MNL{m}(t1),Prevelance_15_99_MNU{m}(t1)] =CI_Sampling_Triangular(Prevelance_15_99_M{1,m}(t1),Prevelance_15_99_M{2,m}(t1),Prevelance_15_99_M{3,m}(t1));

        [IncidenceRate_15_49NL{m}(t1),IncidenceRate_15_49NU{m}(t1)] =CI_Sampling_Triangular(IncidenceRate_15_49{1,m}(t1),IncidenceRate_15_49{2,m}(t1),IncidenceRate_15_49{3,m}(t1));
        [IncidenceRate_15_49_FNL{m}(t1),IncidenceRate_15_49_FNU{m}(t1)] =CI_Sampling_Triangular(IncidenceRate_15_49_F{1,m}(t1),IncidenceRate_15_49_F{2,m}(t1),IncidenceRate_15_49_F{3,m}(t1));
        [IncidenceRate_15_49_MNL{m}(t1),IncidenceRate_15_49_MNU{m}(t1)] =CI_Sampling_Triangular(IncidenceRate_15_49_M{1,m}(t1),IncidenceRate_15_49_M{2,m}(t1),IncidenceRate_15_49_M{3,m}(t1));

        [IncidenceRate_15_99NL{m}(t1),IncidenceRate_15_99NU{m}(t1)] =CI_Sampling_Triangular(IncidenceRate_15_99{1,m}(t1),IncidenceRate_15_99{2,m}(t1),IncidenceRate_15_99{3,m}(t1));
        [IncidenceRate_15_99_FNL{m}(t1),IncidenceRate_15_99_FNU{m}(t1)] =CI_Sampling_Triangular(IncidenceRate_15_99_F{1,m}(t1),IncidenceRate_15_99_F{2,m}(t1),IncidenceRate_15_99_F{3,m}(t1));
        [IncidenceRate_15_99_MNL{m}(t1),IncidenceRate_15_99_MNU{m}(t1)] =CI_Sampling_Triangular(IncidenceRate_15_99_M{1,m}(t1),IncidenceRate_15_99_M{2,m}(t1),IncidenceRate_15_99_M{3,m}(t1));       
        
        [Incidence_15_49NL{m}(t1),Incidence_15_49NU{m}(t1)] =CI_Sampling_Triangular(Incidence_15_49{1,m}(t1),Incidence_15_49{2,m}(t1),Incidence_15_49{3,m}(t1));
        [Incidence_15_49_FNL{m}(t1),Incidence_15_49_FNU{m}(t1)] =CI_Sampling_Triangular(Incidence_15_49_F{1,m}(t1),Incidence_15_49_F{2,m}(t1),Incidence_15_49_F{3,m}(t1));
        [Incidence_15_49_MNL{m}(t1),Incidence_15_49_MNU{m}(t1)] =CI_Sampling_Triangular(Incidence_15_49_M{1,m}(t1),Incidence_15_49_M{2,m}(t1),Incidence_15_49_M{3,m}(t1));

        [Incidence_15_99NL{m}(t1),Incidence_15_99NU{m}(t1)] =CI_Sampling_Triangular(Incidence_15_99{1,m}(t1),Incidence_15_99{2,m}(t1),Incidence_15_99{3,m}(t1));
        [Incidence_15_99_FNL{m}(t1),Incidence_15_99_FNU{m}(t1)] =CI_Sampling_Triangular(Incidence_15_99_F{1,m}(t1),Incidence_15_99_F{2,m}(t1),Incidence_15_99_F{3,m}(t1));
        [Incidence_15_99_MNL{m}(t1),Incidence_15_99_MNU{m}(t1)] =CI_Sampling_Triangular(Incidence_15_99_M{1,m}(t1),Incidence_15_99_M{2,m}(t1),Incidence_15_99_M{3,m}(t1));       

        [NbPeopleGUDNL{m}(t1),NbPeopleGUDNU{m}(t1)] =CI_Sampling_Triangular(NbPeopleGUD{1,m}(t1),NbPeopleGUD{2,m}(t1),NbPeopleGUD{3,m}(t1));
        [NbPeopleGUDFNL{m}(t1),NbPeopleGUDFNU{m}(t1)] =CI_Sampling_Triangular(NbPeopleGUDF{1,m}(t1),NbPeopleGUDF{2,m}(t1),NbPeopleGUDF{3,m}(t1));
        [NbPeopleGUDMNL{m}(t1),NbPeopleGUDMNU{m}(t1)] =CI_Sampling_Triangular(NbPeopleGUDM{1,m}(t1),NbPeopleGUDM{2,m}(t1),NbPeopleGUDM{3,m}(t1));

        [NbPeopleGUDTotalNL{m}(t1),NbPeopleGUDTotalNU{m}(t1)] =CI_Sampling_Triangular(NbPeopleGUDTotal{1,m}(t1),NbPeopleGUDTotal{2,m}(t1),NbPeopleGUDTotal{3,m}(t1));
        [NbPeopleGUDTotalFNL{m}(t1),NbPeopleGUDTotalFNU{m}(t1)] =CI_Sampling_Triangular(NbPeopleGUDFTotal{1,m}(t1),NbPeopleGUDFTotal{2,m}(t1),NbPeopleGUDFTotal{3,m}(t1));
        [NbPeopleGUDTotalMNL{m}(t1),NbPeopleGUDTotalMNU{m}(t1)] =CI_Sampling_Triangular(NbPeopleGUDMTotal{1,m}(t1),NbPeopleGUDMTotal{2,m}(t1),NbPeopleGUDMTotal{3,m}(t1));       

        [TimeGUDNL{m}(t1),TimeGUDNU{m}(t1)] =CI_Sampling_Triangular(TimeGUD{1,m}(t1),TimeGUD{2,m}(t1),TimeGUD{3,m}(t1));
        [TimeGUDFNL{m}(t1),TimeGUDFNU{m}(t1)] =CI_Sampling_Triangular(TimeGUDF{1,m}(t1),TimeGUDF{2,m}(t1),TimeGUDF{3,m}(t1));
        [TimeGUDMNL{m}(t1),TimeGUDMNU{m}(t1)] =CI_Sampling_Triangular(TimeGUDM{1,m}(t1),TimeGUDM{2,m}(t1),TimeGUDM{3,m}(t1));

        [TimeGUDTotalNL{m}(t1),TimeGUDTotalNU{m}(t1)] =CI_Sampling_Triangular(TimeGUDTotal{1,m}(t1),TimeGUDTotal{2,m}(t1),TimeGUDTotal{3,m}(t1));
        [TimeGUDTotalFNL{m}(t1),TimeGUDTotalFNU{m}(t1)] =CI_Sampling_Triangular(TimeGUDFTotal{1,m}(t1),TimeGUDFTotal{2,m}(t1),TimeGUDFTotal{3,m}(t1));
        [TimeGUDTotalMNL{m}(t1),TimeGUDTotalMNU{m}(t1)] =CI_Sampling_Triangular(TimeGUDMTotal{1,m}(t1),TimeGUDMTotal{2,m}(t1),TimeGUDMTotal{3,m}(t1));   
    end
end
dtt=1980:dt:2050;



% 
% %%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, Global 7)

for m=1:7
    for Sc=1:1
        PrevalenceChronicAllScenarios2022CI{m,Sc}={strtrim(sprintf('%10.1f',Prevelance_15_49_F{1,m}((2020-tmin)*2+1))),' ','(',strtrim(sprintf('%10.1f',Prevelance_15_49_FNL{m}((2020-tmin)*2+1))),'-',strtrim(sprintf('%10.1f',Prevelance_15_49_FNU{m}((2020-tmin)*2+1))),')'};
        HARR{m,Sc} = string(PrevalenceChronicAllScenarios2022CI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        PrevalenceRF(m,Sc)=HARRR{m,Sc};
    end
end
for m=1:7
    for Sc=1:1
        PrevalenceChronicAllScenarios2022CI{m,Sc}={strtrim(sprintf('%10.1f',Prevelance_15_49_M{1,m}((2020-tmin)*2+1))),' ','(',strtrim(sprintf('%10.1f',Prevelance_15_49_MNL{m}((2020-tmin)*2+1))),'-',strtrim(sprintf('%10.1f',Prevelance_15_49_MNU{m}((2020-tmin)*2+1))),')'};
        HARR{m,Sc} = string(PrevalenceChronicAllScenarios2022CI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        PrevalenceRM(m,Sc)=HARRR{m,Sc};
     end
end
xlswrite('PrevalenceRF.xlsx',PrevalenceRF,1);
xlswrite('PrevalenceRM.xlsx',PrevalenceRM,1);

for m=1:7
    for Sc=1:1
        IncidenceRMCI{m,Sc}={strtrim(sprintf('%10.1f',Incidence_15_49_M{1,m}((2020-tmin)*2+1)./10^6)),' ','(',strtrim(sprintf('%10.1f',Incidence_15_49_MNL{m}((2020-tmin)*2+1)./10^6)),'-',strtrim(sprintf('%10.1f',Incidence_15_49_MNU{m}((2020-tmin)*2+1)./10^6)),')'};
        HARR{m,Sc} = string(IncidenceRMCI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        IncidenceRMExcel(m,Sc)=HARRR{m,Sc};
     end
end
for m=1:7
    for Sc=1:1
        IncidenceRMCI{m,Sc}={strtrim(sprintf('%10.1f',Incidence_15_49_F{1,m}((2020-tmin)*2+1)./10^6)),' ','(',strtrim(sprintf('%10.1f',Incidence_15_49_FNL{m}((2020-tmin)*2+1)./10^6)),'-',strtrim(sprintf('%10.1f',Incidence_15_49_FNU{m}((2020-tmin)*2+1)./10^6)),')'};
        HARR{m,Sc} = string(IncidenceRMCI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        IncidenceRFExcel(m,Sc)=HARRR{m,Sc};
     end
end
xlswrite('IncidenceRMExcel.xlsx',IncidenceRMExcel,1);
xlswrite('IncidenceRFExcel.xlsx',IncidenceRFExcel,1);


for m=1:7
    for Sc=1:1
        PrevalenceChronicAllScenarios2022CI{m,Sc}={strtrim(sprintf('%10.1f',NbPeopleGUDF{1,m}((2020-tmin)*2+1)./10^6)),' ','(',strtrim(sprintf('%10.1f',NbPeopleGUDFNL{m}((2020-tmin)*2+1)./10^6)),'-',strtrim(sprintf('%10.1f',NbPeopleGUDFNU{m}((2020-tmin)*2+1)./10^6)),')'};
        HARR{m,Sc} = string(PrevalenceChronicAllScenarios2022CI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        NbPeopleGUDRF(m,Sc)=HARRR{m,Sc};
     end
end
for m=1:7
    for Sc=1:1
        PrevalenceChronicAllScenarios2022CI{m,Sc}={strtrim(sprintf('%10.1f',NbPeopleGUDM{1,m}((2020-tmin)*2+1)./10^6)),' ','(',strtrim(sprintf('%10.1f',NbPeopleGUDMNL{m}((2020-tmin)*2+1)./10^6)),'-',strtrim(sprintf('%10.1f',NbPeopleGUDMNU{m}((2020-tmin)*2+1)./10^6)),')'};
        HARR{m,Sc} = string(PrevalenceChronicAllScenarios2022CI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        NbPeopleGUDRM(m,Sc)=HARRR{m,Sc};
     end
end
xlswrite('NbPeopleGUDRF.xlsx',NbPeopleGUDRF,1);
xlswrite('NbPeopleGUDRM.xlsx',NbPeopleGUDRM,1);


for m=1:7
    for Sc=1:1
        PrevalenceChronicAllScenarios2022CI{m,Sc}={strtrim(sprintf('%1.0f',TimeGUDF{1,m}((2020-tmin)*2+1)./10^6)),' ','(',strtrim(sprintf('%1.0f',TimeGUDFNL{m}((2020-tmin)*2+1)./10^6)),'-',strtrim(sprintf('%1.0f',TimeGUDFNU{m}((2020-tmin)*2+1)./10^6)),')'};
        HARR{m,Sc} = string(PrevalenceChronicAllScenarios2022CI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        TimeGUDRF(m,Sc)=HARRR{m,Sc};
     end
end
for m=1:7
    for Sc=1:1
        PrevalenceChronicAllScenarios2022CI{m,Sc}={strtrim(sprintf('%1.0f',TimeGUDM{1,m}((2020-tmin)*2+1)./10^6)),' ','(',strtrim(sprintf('%1.0f',TimeGUDMNL{m}((2020-tmin)*2+1)./10^6)),'-',strtrim(sprintf('%1.0f',TimeGUDMNU{m}((2020-tmin)*2+1)./10^6)),')'};
        HARR{m,Sc} = string(PrevalenceChronicAllScenarios2022CI{m,Sc});
        HARRR{m,Sc} = strcat(HARR{m,Sc}(1),HARR{m,Sc}(2),HARR{m,Sc}(3),HARR{m,Sc}(4),HARR{m,Sc}(5),HARR{m,Sc}(6),HARR{m,Sc}(7));
        TimeGUDRM(m,Sc)=HARRR{m,Sc};
     end
end
xlswrite('TimeGUDRF.xlsx',TimeGUDRF,1);
xlswrite('TimeGUDRM.xlsx',TimeGUDRM,1);

Prevelance_15_49{1,7}((2020-tmin)*2+1)
Prevelance_15_49NL{7}((2020-tmin)*2+1)
Prevelance_15_49NU{7}((2020-tmin)*2+1)

Incidence_15_49{1,7}((2020-tmin)*2+1)./10^6
Incidence_15_49NL{7}((2020-tmin)*2+1)./10^6
Incidence_15_49NU{7}((2020-tmin)*2+1)./10^6

NbPeopleGUD{1,7}((2020-tmin)*2+1)./10^6
NbPeopleGUDNL{7}((2020-tmin)*2+1)./10^6
NbPeopleGUDNU{7}((2020-tmin)*2+1)./10^6

TimeGUD{1,7}((2020-tmin)*2+1)./10^6
TimeGUDNL{7}((2020-tmin)*2+1)./10^6
TimeGUDNU{7}((2020-tmin)*2+1)./10^6

OrderRegion=[2 1 5 4 3 6];
fname1=["Region of the Americas","African Region","Eastern Mediterranean Region","European Region","South-East Asia Region","Western Pacific Region","Global"];
figure
for mm=1:6
    m=OrderRegion(mm);
subplot(3,2,mm)
hold on
p1=plot(1900:dt:2050,Cf0((1900-tmin)*2+1:(2050-tmin)*2+1,m),'k','LineWidth',2)
xlim([1900 2050])
ylabel('Rho')
xlabel('Year')
ylim([0 0.07])
title(fname1(m),'fontweight','bold')
end
legend([p1,p2,p3],{'Women and men','Women','Men'}) 
