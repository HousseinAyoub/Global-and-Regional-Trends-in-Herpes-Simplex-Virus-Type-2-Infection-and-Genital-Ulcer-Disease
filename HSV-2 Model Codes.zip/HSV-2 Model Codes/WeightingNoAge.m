function [WeightData] =WeightingNoAge(DataLR,m,se,pop)

SampleRepated=zeros(length(DataLR{m,se,pop}(:,1)),1);
for i=1:length(DataLR{m,se,pop}(:,1))
    for j=1:length(DataLR{m,se,pop}(:,1))
        if (j~=i)&&(DataLR{m,se,pop}(j,1)==DataLR{m,se,pop}(i,1)) %(DataLR{m}(1,5)==0)&&
           SampleRepated(i)=max([DataLR{m,se,pop}(i,3) DataLR{m,se,pop}(j,3) SampleRepated(i)]);
        end
    end
end
for i=1:length(DataLR{m,se,pop}(:,1))
    if SampleRepated(i)==0
       SampleRepated(i)= DataLR{m,se,pop}(i,3);
    end
end
WeightData=DataLR{m,se,pop}(:,3)./SampleRepated;