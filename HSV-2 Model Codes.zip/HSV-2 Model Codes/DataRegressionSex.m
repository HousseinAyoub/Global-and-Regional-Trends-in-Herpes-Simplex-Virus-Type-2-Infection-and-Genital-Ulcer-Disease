clear all
clc
%%Overall prevalence measures
Data=readtable('HSV-2Data_Age.xlsx','Sheet', 2);
tbl =table(Data.Name, Data.WHO_coded, Data.Gender, Data.Index_Age, Data.health, Data.midpoint, Data.prevalence, Data.n, 'VariableNames', {'NameUSA', 'Region', 'Sex', 'Age', 'Study_pop', 'Year','Prevalence','Sample_Size'});

%NHANES data
DataF=xlsread('NHANES_Female.xlsx', 1);
DataFL=xlsread('NHANES_Female.xlsx', 2);
DataFU=xlsread('NHANES_Female.xlsx', 3);

DataM=xlsread('NHANES_Male.xlsx', 1);
DataML=xlsread('NHANES_Male.xlsx', 2);
DataMU=xlsread('NHANES_Male.xlsx', 3);

%%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, USA 7)
   
declineData=[0.98 0.98 0.97 0.99 0.97 0.99 0];
declineDataLower=[0.97 0.96 0.94 0.98 0.94 0.97 0];
declineDataUpper=[0.99 0.99 1.01 1.00 0.99 1.00 0];



%All_ populations
for m=1:7 %%Over each region

%%%Extrting data
for se=1:2 %Women 1 and Men 2
for ag=1:1
for pop=1:1 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==1
Data_All_population=tbl((tbl.NameUSA ~="NHANES")&(tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Study_pop ==1)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
elseif m==7
Data_All_population=tbl((tbl.NameUSA =="NHANES")&(tbl.Study_pop ==1)&(tbl.Sex ==se)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
else    
Data_All_population=tbl((tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Study_pop ==1)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
end
Data_All_population_YP=table(Data_All_population.Year,Data_All_population.Prevalence,Data_All_population.Sample_Size);
DataAllP{m,se,ag,pop}=table2array(Data_All_population_YP);
DataAllP_Lower{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);
DataAllP_Upper{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);

DataAllP{m,se,ag,pop}(:,4)=Weighting(DataAllP,m,se,ag,pop);
DataAllP_Lower{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);
DataAllP_Upper{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);

for i=1:length(DataAllP{m,se,ag,pop}(:,1))
    [phat,pci] = binofit(DataAllP{m,se,ag,pop}(i,2)/100*DataAllP{m,se,ag,pop}(i,3),DataAllP{m,se,ag,pop}(i,3));
    DataAllP_Lower{m,se,ag,pop}(i,2)=100.*pci(1);
    DataAllP_Upper{m,se,ag,pop}(i,2)=100.*pci(2);
    
    DataAllP_Lower{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
    DataAllP_Upper{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
end
end
end

for ag=1:1
for pop=1:1 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==7
   if pop==1 
       if se==1 
       DataAllP{m,se,ag,pop}=[DataF(:,1) 100.*DataF(:,ag+1) ones(length(DataF(:,ag+1)),1) ones(length(DataF(:,ag+1)),1)];
       DataAllP_Lower{m,se,ag,pop}=[DataFL(:,1) 100.*DataFL(:,ag+1) ones(length(DataFL(:,ag+1)),1) ones(length(DataFL(:,ag+1)),1)];
       DataAllP_Upper{m,se,ag,pop}=[DataFU(:,1) 100.*DataFU(:,ag+1) ones(length(DataFU(:,ag+1)),1) ones(length(DataFU(:,ag+1)),1)];
       else
       DataAllP{m,se,ag,pop}=[DataM(:,1) 100.*DataM(:,ag+1) ones(length(DataM(:,ag+1)),1) ones(length(DataM(:,ag+1)),1)];
       DataAllP_Lower{m,se,ag,pop}=[DataML(:,1) 100.*DataML(:,ag+1) ones(length(DataML(:,ag+1)),1) ones(length(DataML(:,ag+1)),1)];
       DataAllP_Upper{m,se,ag,pop}=[DataMU(:,1) 100.*DataMU(:,ag+1) ones(length(DataMU(:,ag+1)),1) ones(length(DataMU(:,ag+1)),1)];
       end
   end
end
   
DataAllPR{m,se}=DataAllP{m,se,ag,pop};
DataAllP_LowerR{m,se}=DataAllP_Lower{m,se,ag,pop};
DataAllP_UpperR{m,se}=DataAllP_Upper{m,se,ag,pop};  
end
end
end
end
    

m=2;
se=2;
mdl = fitlm(DataAllPR{m,se}(:,1),DataAllPR{m,se}(:,2))
mdl.Coefficients

hold on
scatter(DataAllPR{m,se}(:,1),DataAllPR{m,se}(:,2),'filled')
plot(mdl)
% regress(DataAllPR{2}(:,1),DataAllPR{2}(:,2),0.01)

for m=1:7 %%Over each region
%%%Extrting data
for se=1:2 %Women 1 and Men 2
    for n=1:length(DataAllPR{m,se}(:,1))
    if DataAllPR{m,se}(n,1)<=2000
       PrevalenceLess2000{m,se}(n)=DataAllPR{m,se}(n,2);
       PrevalenceLess2000L{m,se}(n)=DataAllP_LowerR{m,se}(n,2);
       PrevalenceLess2000U{m,se}(n)=DataAllP_UpperR{m,se}(n,2);
    else
       PrevalenceLess2000{m,se}(n)=0;
       PrevalenceLess2000L{m,se}(n)=0;
       PrevalenceLess2000U{m,se}(n)=0;
    end
    end
    PrevalenceLess2000{m,se}(PrevalenceLess2000{m,se}==0)=[];
    PrevalenceLess2000L{m,se}(PrevalenceLess2000L{m,se}==0)=[];
    PrevalenceLess2000U{m,se}(PrevalenceLess2000U{m,se}==0)=[];

    PooledPrevalence(m,se)=mean(PrevalenceLess2000{m,se});
    PooledPrevalenceL(m,se)=mean(PrevalenceLess2000L{m,se});
    PooledPrevalenceU(m,se)=mean(PrevalenceLess2000U{m,se});

end
end
save('PooledPrevalence.mat','PooledPrevalence')
save('PooledPrevalenceL.mat','PooledPrevalenceL')
save('PooledPrevalenceU.mat','PooledPrevalenceU')


    