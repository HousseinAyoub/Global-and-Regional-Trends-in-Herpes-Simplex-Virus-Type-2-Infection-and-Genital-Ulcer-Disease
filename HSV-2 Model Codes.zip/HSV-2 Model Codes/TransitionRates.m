function [fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1,ProportionGenitalLession2,ProportionGenitalLession3] =TransitionRates(UI)
%Fraction of Symptomatic
fs=0.374*(1+UI);
%%Fraction of individuals with GUD recurrences due to HSV-2 following a documented first episode
if UI==0.3
   fGUD=1;
else
   fGUD=0.89*(1+UI);
end
%Symptomatic
shed_freqS=0.201*(1+UI);
cycle_freqS=17.9*(1+UI);
length_dur_primary=20.5*(1+UI);
% duration of latency from latent to reactivation v2
v2S=365*(1-shed_freqS)/cycle_freqS;
% duration of reactivation v3
v3S=365*shed_freqS/cycle_freqS;
%The progression rates from one stage to other per year is:
pi1S=365*(1/length_dur_primary);  %per year
pi2S=365*(1/v2S);
pi3S=365*(1/v3S);

%Asymptomatic
shed_freqA=0.102*(1+UI);
cycle_freqA=12.5*(1+UI);
length_dur_primary=20.5*(1+UI);
% duration of latency from latent to reactivation v2
v2A=365*(1-shed_freqA)/cycle_freqA;
% duration of reactivation v3
v3A=365*shed_freqA/cycle_freqA;
%The progression rates from one stage to other per year is:
pi1A=365*(1/length_dur_primary);  %per year
pi2A=365*(1/v2A);
pi3A=365*(1/v3A);

ProportionGenitalLession1=0.155*(1+UI);
ProportionGenitalLession2=0.14*(1+UI);
ProportionGenitalLession3=0.123*(1+UI);
end