%%Data Extraction
clear all
clc
%%Import dataset
%%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, Global 7)

%%Overall prevalence measures
Data=readtable('HSV-2Data_Age.xlsx','Sheet', 2);
tbl =table(Data.WHO_coded, Data.Gender, Data.Index_Age, Data.health, Data.midpoint, Data.prevalence, Data.n, 'VariableNames', {'Region', 'Sex', 'Age', 'Study_pop', 'Year','Prevalence','Sample_Size'});

%All_ populations
for m=1:7 %%Over each region
for se=1:2 %Women 1 and Men 2
for ag=1:20    
for pop=1:3 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==7
Data_All_population=tbl((tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
else
Data_All_population=tbl((tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
end
Data_All_population_YP=table(Data_All_population.Year,Data_All_population.Prevalence,Data_All_population.Sample_Size);
DataAllP{m,se,ag,pop}=table2array(Data_All_population_YP);
DataAllP_Lower{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);
DataAllP_Upper{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);

DataAllP{m,se,ag,pop}(:,4)=Weighting(DataAllP,m,se,ag,pop);
DataAllP_Lower{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);
DataAllP_Upper{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);

for i=1:length(DataAllP{m,se,ag,pop}(:,1))
    [phat,pci] = binofit(DataAllP{m,se,ag,pop}(i,2)/100*DataAllP{m,se,ag,pop}(i,3),DataAllP{m,se,ag,pop}(i,3));
    DataAllP_Lower{m,se,ag,pop}(i,2)=100.*pci(1);
    DataAllP_Upper{m,se,ag,pop}(i,2)=100.*pci(2);
    
    DataAllP_Lower{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
    DataAllP_Upper{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
end
end
end
end
end

%%test=[DataAllP{7,1,1}(:,2) DataAllP_Lower{7,1,1}(:,2) DataAllP_Upper{7,1,1}(:,2)]

