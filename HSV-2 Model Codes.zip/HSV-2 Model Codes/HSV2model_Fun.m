%%%HSV-2 Model
function [dydt,L_M,L_F,Incidence_M,Incidence_F]=HSV2model_Fun(t ,x, na,nr,n_stage,fs,fGUD,pwlaw,Phi_male,Phi_female,q,alphaZ,YearW,r0,D0,resM,resF,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A)
%%
eps=1.0e-10;
% Degree of assortativeness for age group mixing
e_age=0.7;
% Degree of assortativeness for risk group mixing
e_risk=0.3;
%% HSV2 parameters

DL1=1/1;
DL2=1/8;
 
% Transmission probability of infection per coital act
p=0.01;

%tau=1;  % one year
%1 week - 15 years; a hierarchy of durations based on the risk groups of each of the partners in the partnership. Duration is shorter the higher is the risk group.
tau=[15 12 9 6 1;12 9 6 1 6/12;9 6 1 6/12 3/12;6 1 6/12 3/12 1/12;1 6/12 3/12 1/12 7/365];

% Frequency of coital acts
FrequencyOfCoitalActA=[3.90 3.50 3.20 2.90 2.50 2.20 1.90 1.50 1.20 0.87];  
FrequencyOfCoitalAct=zeros(na,1);
FrequencyOfCoitalAct(4:13)=365.*FrequencyOfCoitalActA/7; %%Per year  from 15-19 to 60-64 years

t_primary=zeros(na,nr,nr);
for i=1:nr
    for j=1:nr
        for a=4:13
            t_primary(a,i,j)=1-(1-p)^(FrequencyOfCoitalAct(a)*tau(i,j));
        end
    end
end
t_reactivation=t_primary;
% For balancing of partnerships
w=1; 
% e_age,e_risk,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,DL1,DL2,t_primary,t_reactivation,w
%% Demographic parameters
% Average risk of HSV-2 exposure
C_m=1;
C_f=1;

%% Variable names used in stating the ODEs

dS_mdt=zeros(na,nr);
dIA1_mdt=zeros(na,nr);
dIA2_mdt=zeros(na,nr);
dIA2R_mdt=zeros(na,nr);
dIA3_mdt=zeros(na,nr);
dIA3R_mdt=zeros(na,nr);
dIA4_mdt=zeros(na,nr);
dIA4R_mdt=zeros(na,nr);
dIS1_mdt=zeros(na,nr);
dIS2_mdt=zeros(na,nr);
dIS2R_mdt=zeros(na,nr);
dIS3_mdt=zeros(na,nr);
dIS3R_mdt=zeros(na,nr);
dIS4_mdt=zeros(na,nr);
dIS4R_mdt=zeros(na,nr);

dS_fdt=zeros(na,nr);
dIA1_fdt=zeros(na,nr);
dIA2_fdt=zeros(na,nr);
dIA2R_fdt=zeros(na,nr);
dIA3_fdt=zeros(na,nr);
dIA3R_fdt=zeros(na,nr);
dIA4_fdt=zeros(na,nr);
dIA4R_fdt=zeros(na,nr);
dIS1_fdt=zeros(na,nr);
dIS2_fdt=zeros(na,nr);
dIS2R_fdt=zeros(na,nr);
dIS3_fdt=zeros(na,nr);
dIS3R_fdt=zeros(na,nr);
dIS4_fdt=zeros(na,nr);
dIS4R_fdt=zeros(na,nr);
%%%
xm=reshape(x(1:na*nr*n_stage),nr,na*n_stage);
xf=reshape(x(na*nr*n_stage+1:end),nr,na*n_stage);
xm=xm';
xf=xf';

S_m=xm(1:na,:);
IA1_m=xm(na+1:2*na,:);
IA2_m=xm(2*na+1:3*na,:);
IA2R_m=xm(3*na+1:4*na,:);
IA3_m=xm(4*na+1:5*na,:);
IA3R_m=xm(5*na+1:6*na,:);
IA4_m=xm(6*na+1:7*na,:);
IA4R_m=xm(7*na+1:8*na,:);
IS1_m=xm(8*na+1:9*na,:);
IS2_m=xm(9*na+1:10*na,:);
IS2R_m=xm(10*na+1:11*na,:);
IS3_m=xm(11*na+1:12*na,:);
IS3R_m=xm(12*na+1:13*na,:);
IS4_m=xm(13*na+1:14*na,:);
IS4R_m=xm(14*na+1:15*na,:);

S_f=xf(1:na,:);
IA1_f=xf(na+1:2*na,:);
IA2_f=xf(2*na+1:3*na,:);
IA2R_f=xf(3*na+1:4*na,:);
IA3_f=xf(4*na+1:5*na,:);
IA3R_f=xf(5*na+1:6*na,:);
IA4_f=xf(6*na+1:7*na,:);
IA4R_f=xf(7*na+1:8*na,:);
IS1_f=xf(8*na+1:9*na,:);
IS2_f=xf(9*na+1:10*na,:);
IS2R_f=xf(10*na+1:11*na,:);
IS3_f=xf(11*na+1:12*na,:);
IS3R_f=xf(12*na+1:13*na,:);
IS4_f=xf(13*na+1:14*na,:);
IS4R_f=xf(14*na+1:15*na,:);

N_mm=S_m+IA1_m+IA2_m+IA2R_m+IA3_m+IA3R_m+IA4_m+IA4R_m+IS1_m+IS2_m+IS2R_m+IS3_m+IS3R_m+IS4_m+IS4R_m;
N_ff=S_f+IA1_f+IA2_f+IA2R_f+IA3_f+IA3R_f+IA4_f+IA4R_f+IS1_f+IS2_f+IS2R_f+IS3_f+IS3R_f+IS4_f+IS4R_f;
%%
mortality_rate_male=zeros(na,1);
mortality_rate_female=zeros(na,1);

b_0m=resM(1);
b_1m=resM(2);
b_2m=resM(3);
b_0f=resF(1);
b_1f=resF(2);
b_2f=resF(3);

c_0m=resM(6);
c_1m=resM(7);
c_2m=resM(8);
c_3m=resM(5);
c_4m=resM(4);
c_0f=resF(6);
c_1f=resF(7);
c_2f=resF(8);
c_3f=resF(5);
c_4f=resF(4);

birth_rate_male=b_0m*exp(-((t-b_1m)/b_2m)^2);
birth_rate_female=b_0f*exp(-((t-b_1f)/b_2f)^2);
eta=1/5;
for a=1:na
    mortality_rate_male(a)=c_0m*exp(-((t-c_1m)/c_2m)^2)/(1+exp(-c_3m*(a-c_4m)));
    mortality_rate_female(a)=c_0f*exp(-((t-c_1f)/c_2f)^2)/(1+exp(-c_3f*(a-c_4f)));   
end
%% Force of Infection
%% rho
rho_m=zeros(na,nr);
rho_f=zeros(na,nr);

Cf0=(1+alphaZ/(1+exp(((t-YearW)/D0)))).*r0;
Cm0=Cf0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% power law function in level of risk of exposure
for a=4:na
    for i=1:nr
        rho_m(a,i)=C_m*Phi_male(a)*pwlaw(i)*Cm0;
        rho_f(a,i)=C_f*Phi_female(a)*pwlaw(i)*Cf0;
    end
end
%% rho*population

%sum over all stages for each age and risk group : each would be matrix (2 dim)
rho_sum_stage_male=rho_m.*N_mm;
rho_sum_stage_female=rho_f.*N_ff;

% sum over risk for each age (array over age)
denum_mix_risk_males=sum(rho_sum_stage_male,2);
denum_mix_risk_females=sum(rho_sum_stage_female,2);

%denumenator of the age mixing matrix: the previous sum over all risk and age 
denum_mix_age_male=sum(denum_mix_risk_males);
denum_mix_age_female=sum(denum_mix_risk_females);
%% identity matrices
idty_risk=eye(nr,nr);
idty_age=eye(na,na);
idty_age(1:3,:)=0; %zeros for the first three age groups
% Age mixing matrix H(a,b)
H_m=zeros(na,na);
H_f=zeros(na,na);

for a=4:na
    for b=4:na
        H_m(a,b)=e_age*idty_age(a,b)+(1-e_age)*(denum_mix_risk_females(b)/(denum_mix_age_female+eps));  
        H_f(a,b)=e_age*idty_age(a,b)+(1-e_age)*(denum_mix_risk_males(b)/(denum_mix_age_male+eps));
    end
end
%% Risk mixing matrix G(i,j,b)
G_m=zeros(nr,nr,na);
G_f=zeros(nr,nr,na);

for b=4:na
    for i=1:nr
        for j=1:nr
            G_m(i,j,b)=e_risk*idty_risk(i,j)+(1-e_risk)*(rho_sum_stage_female(b,j)/(denum_mix_risk_females(b)+eps));  
            G_f(i,j,b)=e_risk*idty_risk(i,j)+(1-e_risk)*(rho_sum_stage_male(b,j)/(denum_mix_risk_males(b)+eps));
        end
    end
end

%% Balancing of partnerships
BB_Sm=zeros(nr,nr,na,na);
BB_Sf=zeros(nr,nr,na,na);

B_SmSf=zeros(nr,nr,na,na);

for a=4:na
    for i=1:nr
        for b=4:na
            for j=1:nr
                BB_Sm(i,j,a,b)=rho_m(a,i)*H_m(a,b)*G_m(i,j,b);
                BB_Sf(i,j,a,b)=rho_f(a,i)*H_f(a,b)*G_f(i,j,b);                                      
                B_SmSf(i,j,a,b)=(BB_Sm(i,j,a,b)*N_mm(a,i))/(BB_Sf(i,j,a,b)*N_ff(a,i)+eps);
            end
        end
    end
end


B1=B_SmSf(:);
Cm1=BB_Sm(:);
Cf1=BB_Sf(:);
index=find(B1~=1);
Cm1(index(:))=Cm1(index(:)).*(B_SmSf(index(:))).^ (- (1-w));
Cf1(index(:))=Cf1(index(:)).*(B_SmSf(index(:))).^ w;
Cm1(isnan(BB_Sm))=0;
Cf1(isnan(BB_Sf))=0;
% %reshape the vectors Cm1 and Cm2 because into i,j,a,b
Cm_reshaped=reshape(Cm1,nr,nr,na,na);
Cf_reshaped=reshape(Cf1,nr,nr,na,na);
%% Lambda_m and Lambda_f
Lambda_m=zeros(na,nr);
Lambda_f=zeros(na,nr);

Lm=zeros(na,nr,nr);
Lf=zeros(na,nr,nr);

for i=1:nr
    for j=1:nr
        Lm(4:na,i,j)=(t_primary(4:na,i,j).*(IA1_f(4:na,j)+IS1_f(4:na,j))...
            +t_reactivation(4:na,i,j).*(IA2R_f(4:na,j)+IA3R_f(4:na,j)+IA4R_f(4:na,j)+IS2R_f(4:na,j)+IS3R_f(4:na,j)+IS4R_f(4:na,j)))./(N_ff(4:na,j)+eps);

        Lf(4:na,i,j)=(t_primary(4:na,i,j).*(IA1_m(4:na,j)+IS1_m(4:na,j))...
            +t_reactivation(4:na,i,j).*(IA2R_m(4:na,j)+IA3R_m(4:na,j)+IA4R_m(4:na,j)+IS2R_m(4:na,j)+IS3R_m(4:na,j)+IS4R_m(4:na,j)))./(N_mm(4:na,j)+eps);
    end
end

for i=1:nr
    for j=1:nr
        for a=4:na
            for b=4:na
                Lambda_m(a,i)=Lambda_m(a,i)+Cm_reshaped(i,j,a,b)*Lm(b,i,j);
                Lambda_f(a,i)=Lambda_f(a,i)+Cf_reshaped(i,j,a,b)*Lf(b,i,j);
            end
        end
    end
end

L_M=(sum(Lambda_m,2))';
L_F=(sum(Lambda_f,2))';
%% Incidence
Incidence_M=zeros(1,na);
Incidence_F=zeros(1,na);
for a=1:na
    PSm=0;
    PSf=0;
    for i=1:nr
        PSm=PSm+Lambda_m(a,i)*S_m(a,i);
        PSf=PSf+q*Lambda_f(a,i)*S_f(a,i); %
    end
Incidence_M(a)=PSm;
Incidence_F(a)=PSf;
end
%% The system
%% a=1
%% Male
dS_mdt(1,:)=birth_rate_male*sum(N_mm,1)-(eta+mortality_rate_male(1)+Lambda_m(1,:)).*S_m(1,:);

dIA1_mdt(1,:)=(1-fs)*Lambda_m(1,:).*S_m(1,:)-(eta+mortality_rate_male(1)+pi1A)*IA1_m(1,:);
dIA2_mdt(1,:)=(1-fGUD)*pi1A*IS1_m(1,:)+pi1A*IA1_m(1,:)+pi3A*IA2R_m(1,:)-(eta+mortality_rate_male(1)+pi2A+DL1)*IA2_m(1,:);
dIA2R_mdt(1,:)=pi2A*IA2_m(1,:)-(eta+mortality_rate_male(1)+pi3A+DL1)*IA2R_m(1,:);
dIA3_mdt(1,:)=DL1*IA2_m(1,:)+pi3A*IA3R_m(1,:)-(eta+mortality_rate_male(1)+pi2A+DL2)*IA3_m(1,:);
dIA3R_mdt(1,:)=DL1*IA2R_m(1,:)+pi2A*IA3_m(1,:)-(eta+mortality_rate_male(1)+pi3A+DL2)*IA3R_m(1,:);    
dIA4_mdt(1,:)=DL2*IA3_m(1,:)+pi3A*IA4R_m(1,:)-(eta+mortality_rate_male(1)+pi2A)*IA4_m(1,:);
dIA4R_mdt(1,:)=DL2*IA3R_m(1,:)+pi2A*IA4_m(1,:)-(eta+mortality_rate_male(1)+pi3A)*IA4R_m(1,:);

dIS1_mdt(1,:)=fs*Lambda_m(1,:).*S_m(1,:)-(eta+mortality_rate_male(1)+pi1S)*IS1_m(1,:);
dIS2_mdt(1,:)=fGUD*pi1S*IS1_m(1,:)+pi3S*IS2R_m(1,:)-(eta+mortality_rate_male(1)+pi2S+DL1)*IS2_m(1,:);
dIS2R_mdt(1,:)=pi2S*IS2_m(1,:)-(eta+mortality_rate_male(1)+pi3S+DL1)*IS2R_m(1,:);
dIS3_mdt(1,:)=DL1*IS2_m(1,:)+pi3S*IS3R_m(1,:)-(eta+mortality_rate_male(1)+pi2S+DL2)*IS3_m(1,:);
dIS3R_mdt(1,:)=DL1*IS2R_m(1,:)+pi2S*IS3_m(1,:)-(eta+mortality_rate_male(1)+pi3S+DL2)*IS3R_m(1,:);
dIS4_mdt(1,:)=DL2*IS3_m(1,:)+pi3S*IS4R_m(1,:)-(eta+mortality_rate_male(1)+pi2S)*IS4_m(1,:);
dIS4R_mdt(1,:)=DL2*IS3R_m(1,:)+pi2S*IS4_m(1,:)-(eta+mortality_rate_male(1)+pi3S)*IS4R_m(1,:);

%% Female
dS_fdt(1,:)=birth_rate_female*sum(N_ff,1)-(eta+mortality_rate_female(1)+q*Lambda_f(1,:)).*S_f(1,:);
dIA1_fdt(1,:)=(1-fs)*q*Lambda_f(1,:).*S_f(1,:)-(eta+mortality_rate_female(1)+pi1A)*IA1_f(1,:);
dIA2_fdt(1,:)=(1-fGUD)*pi1A*IS1_f(1,:)+pi1A*IA1_f(1,:)+pi3A*IA2R_f(1,:)-(eta+mortality_rate_female(1)+pi2A+DL1)*IA2_f(1,:);
dIA2R_fdt(1,:)=pi2A*IA2_f(1,:)-(eta+mortality_rate_female(1)+pi3A+DL1)*IA2R_f(1,:);
dIA3_fdt(1,:)=DL1*IA2_f(1,:)+pi3A*IA3R_f(1,:)-(eta+mortality_rate_female(1)+pi2A+DL2)*IA3_f(1,:);    
dIA3R_fdt(1,:)=DL1*IA2R_f(1,:)+pi2A*IA3_f(1,:)-(eta+mortality_rate_female(1)+pi3A+DL2)*IA3R_f(1,:);
dIA4_fdt(1,:)=DL2*IA3_f(1,:)+pi3A*IA4R_f(1,:)-(eta+mortality_rate_female(1)+pi2A)*IA4_f(1,:);
dIA4R_fdt(1,:)=DL2*IA3R_f(1,:)+pi2A*IA4_f(1,:)-(eta+mortality_rate_female(1)+pi3A)*IA4R_f(1,:);

dIS1_fdt(1,:)=fs*q*Lambda_f(1,:).*S_f(1,:)-(eta+mortality_rate_female(1)+pi1S)*IS1_f(1,:);
dIS2_fdt(1,:)=fGUD*pi1S*IS1_f(1,:)+pi3S*IS2R_f(1,:)-(eta+mortality_rate_female(1)+pi2S+DL1)*IS2_f(1,:);
dIS2R_fdt(1,:)=pi2S*IS2_f(1,:)-(eta+mortality_rate_female(1)+pi3S+DL1)*IS2R_f(1,:);    
dIS3_fdt(1,:)=DL1*IS2_f(1,:)+pi3S*IS3R_f(1,:)-(eta+mortality_rate_female(1)+pi2S+DL2)*IS3_f(1,:);    
dIS3R_fdt(1,:)=DL1*IS2R_f(1,:)+pi2S*IS3_f(1,:)-(eta+mortality_rate_female(1)+pi3S+DL2)*IS3R_f(1,:);    
dIS4_fdt(1,:)=DL2*IS3_f(1,:)+pi3S*IS4R_f(1,:)-(eta+mortality_rate_female(1)+pi2S)*IS4_f(1,:);    
dIS4R_fdt(1,:)=DL2*IS3R_f(1,:)+pi2S*IS4_f(1,:)-(eta+mortality_rate_female(1)+pi3S)*IS4R_f(1,:);
%% a>1
for a=2:na
    %Male
    dS_mdt(a,:)=eta*S_m(a-1,:)-(eta+mortality_rate_male(a)+Lambda_m(a,:)).*S_m(a,:);        
    dIA1_mdt(a,:)=(1-fs)*Lambda_m(a,:).*S_m(a,:)+eta*IA1_m(a-1,:)-(eta+mortality_rate_male(a)+pi1A)*IA1_m(a,:);        
    dIA2_mdt(a,:)=(1-fGUD)*pi1A*IS1_m(a,:)+pi1A*IA1_m(a,:)+pi3A*IA2R_m(a,:)+eta*IA2_m(a-1,:)-(eta+mortality_rate_male(a)+pi2A+DL1)*IA2_m(a,:);
    dIA2R_mdt(a,:)=pi2A*IA2_m(a,:)+eta*IA2R_m(a-1,:)-(eta+mortality_rate_male(a)+pi3A+DL1)*IA2R_m(a,:);        
    dIA3_mdt(a,:)=DL1*IA2_m(a,:)+pi3A*IA3R_m(a,:)+eta*IA3_m(a-1,:)-(eta+mortality_rate_male(a)+pi2A+DL2)*IA3_m(a,:);
    dIA3R_mdt(a,:)=DL1*IA2R_m(a,:)+pi2A*IA3_m(a,:)+eta*IA3R_m(a-1,:)-(eta+mortality_rate_male(a)+pi3A+DL2)*IA3R_m(a,:);        
    dIA4_mdt(a,:)=DL2*IA3_m(a,:)+pi3A*IA4R_m(a,:)+eta*IA4_m(a-1,:)-(eta+mortality_rate_male(a)+pi2A)*IA4_m(a,:);
    dIA4R_mdt(a,:)=DL2*IA3R_m(a,:)+pi2A*IA4_m(a,:)+eta*IA4R_m(a-1,:)-(eta+mortality_rate_male(a)+pi3A)*IA4R_m(a,:);          
    
    dIS1_mdt(a,:)=fs*Lambda_m(a,:).*S_m(a,:)+eta*IS1_m(a-1,:)-(eta+mortality_rate_male(a)+pi1S)*IS1_m(a,:);        
    dIS2_mdt(a,:)=fGUD*pi1S*IS1_m(a,:)+pi3S*IS2R_m(a,:)+eta*IS2_m(a-1,:)-(eta+mortality_rate_male(a)+pi2S+DL1)*IS2_m(a,:);
    dIS2R_mdt(a,:)=pi2S*IS2_m(a,:)+eta*IS2R_m(a-1,:)-(eta+mortality_rate_male(a)+pi3S+DL1)*IS2R_m(a,:);        
    dIS3_mdt(a,:)=DL1*IS2_m(a,:)+pi3S*IS3R_m(a,:)+eta*IS3_m(a-1,:)-(eta+mortality_rate_male(a)+pi2S+DL2)*IS3_m(a,:);
    dIS3R_mdt(a,:)=DL1*IS2R_m(a,:)+pi2S*IS3_m(a,:)+eta*IS3R_m(a-1,:)-(eta+mortality_rate_male(a)+pi3S+DL2)*IS3R_m(a,:);        
    dIS4_mdt(a,:)=DL2*IS3_m(a,:)+pi3S*IS4R_m(a,:)+eta*IS4_m(a-1,:)-(eta+mortality_rate_male(a)+pi2S)*IS4_m(a,:);
    dIS4R_mdt(a,:)=DL2*IS3R_m(a,:)+pi2S*IS4_m(a,:)+eta*IS4R_m(a-1,:)-(eta+mortality_rate_male(a)+pi3S)*IS4R_m(a,:);
    %Female
    dS_fdt(a,:)=eta*S_f(a-1,:)-(eta+mortality_rate_female(a)+q*Lambda_f(a,:)).*S_f(a,:); 
    dIA1_fdt(a,:)=(1-fs)*q*Lambda_f(a,:).*S_f(a,:)+eta*IA1_f(a-1,:)-(eta+mortality_rate_female(a)+pi1A)*IA1_f(a,:);        
    dIA2_fdt(a,:)=(1-fGUD)*pi1A*IS1_f(a,:)+pi1A*IA1_f(a,:)+pi3A*IA2R_f(a,:)+eta*IA2_f(a-1,:)-(eta+mortality_rate_female(a)+pi2A+DL1)*IA2_f(a,:);        
    dIA2R_fdt(a,:)=pi2A*IA2_f(a,:)+eta*IA2R_f(a-1,:)-(eta+mortality_rate_female(a)+pi3A+DL1)*IA2R_f(a,:);        
    dIA3_fdt(a,:)=DL1*IA2_f(a,:)+pi3A*IA3R_f(a,:)+eta*IA3_f(a-1,:)-(eta+mortality_rate_female(a)+pi2A+DL2)*IA3_f(a,:);
    dIA3R_fdt(a,:)=DL1*IA2R_f(a,:)+pi2A*IA3_f(a,:)+eta*IA3R_f(a-1,:)-(eta+mortality_rate_female(a)+pi3A+DL2)*IA3R_f(a,:);        
    dIA4_fdt(a,:)=DL2*IA3_f(a,:)+pi3A*IA4R_f(a,:)+eta*IA4_f(a-1,:)-(eta+mortality_rate_female(a)+pi2A)*IA4_f(a,:);
    dIA4R_fdt(a,:)=DL2*IA3R_f(a,:)+pi2A*IA4_f(a,:)+eta*IA4R_f(a-1,:)-(eta+mortality_rate_female(a)+pi3A)*IA4R_f(a,:);        
    
    dIS1_fdt(a,:)=fs*q*Lambda_f(a,:).*S_f(a,:)+eta*IS1_f(a-1,:)-(eta+mortality_rate_female(a)+pi1S)*IS1_f(a,:);
    dIS2_fdt(a,:)=fGUD*pi1S*IS1_f(a,:)+pi3S*IS2R_f(a,:)+eta*IS2_f(a-1,:)-(eta+mortality_rate_female(a)+pi2S+DL1)*IS2_f(a,:);
    dIS2R_fdt(a,:)=pi2S*IS2_f(a,:)+eta*IS2R_f(a-1,:)-(eta+mortality_rate_female(a)+pi3S+DL1)*IS2R_f(a,:);        
    dIS3_fdt(a,:)=DL1*IS2_f(a,:)+pi3S*IS3R_f(a,:)+eta*IS3_f(a-1,:)-(eta+mortality_rate_female(a)+pi2S+DL2)*IS3_f(a,:);
    dIS3R_fdt(a,:)=DL1*IS2R_f(a,:)+pi2S*IS3_f(a,:)+eta*IS3R_f(a-1,:)-(eta+mortality_rate_female(a)+pi3S+DL2)*IS3R_f(a,:);        
    dIS4_fdt(a,:)=DL2*IS3_f(a,:)+pi3S*IS4R_f(a,:)+eta*IS4_f(a-1,:)-(eta+mortality_rate_female(a)+pi2S)*IS4_f(a,:);
    dIS4R_fdt(a,:)=DL2*IS3R_f(a,:)+pi2S*IS4_f(a,:)+eta*IS4R_f(a-1,:)-(eta+mortality_rate_female(a)+pi3S)*IS4R_f(a,:);
end
%% Output
dS_mdt=dS_mdt';
dIA1_mdt=dIA1_mdt';
dIA2_mdt=dIA2_mdt';
dIA2R_mdt=dIA2R_mdt';
dIA3_mdt=dIA3_mdt';
dIA3R_mdt=dIA3R_mdt';
dIA4_mdt=dIA4_mdt';
dIA4R_mdt=dIA4R_mdt';
dIS1_mdt=dIS1_mdt';
dIS2_mdt=dIS2_mdt';
dIS2R_mdt=dIS2R_mdt';
dIS3_mdt=dIS3_mdt';
dIS3R_mdt=dIS3R_mdt';
dIS4_mdt=dIS4_mdt';
dIS4R_mdt=dIS4R_mdt';

dS_fdt=dS_fdt';
dIA1_fdt=dIA1_fdt';
dIA2_fdt=dIA2_fdt';
dIA2R_fdt=dIA2R_fdt';
dIA3_fdt=dIA3_fdt';
dIA3R_fdt=dIA3R_fdt';
dIA4_fdt=dIA4_fdt';
dIA4R_fdt=dIA4R_fdt';
dIS1_fdt=dIS1_fdt';
dIS2_fdt=dIS2_fdt';
dIS2R_fdt=dIS2R_fdt';
dIS3_fdt=dIS3_fdt';
dIS3R_fdt=dIS3R_fdt';
dIS4_fdt=dIS4_fdt';
dIS4R_fdt=dIS4R_fdt';

dydt(1:nr*na)=dS_mdt(:);
dydt(nr*na+1:2*nr*na)=dIA1_mdt(:);
dydt(2*nr*na+1:3*nr*na)=dIA2_mdt(:);
dydt(3*nr*na+1:4*nr*na)=dIA2R_mdt(:);
dydt(4*nr*na+1:5*nr*na)=dIA3_mdt(:);
dydt(5*nr*na+1:6*nr*na)=dIA3R_mdt(:);
dydt(6*nr*na+1:7*nr*na)=dIA4_mdt(:);
dydt(7*nr*na+1:8*nr*na)=dIA4R_mdt(:);
dydt(8*nr*na+1:9*nr*na)=dIS1_mdt(:);
dydt(9*nr*na+1:10*nr*na)=dIS2_mdt(:);
dydt(10*nr*na+1:11*nr*na)=dIS2R_mdt(:);
dydt(11*nr*na+1:12*nr*na)=dIS3_mdt(:);
dydt(12*nr*na+1:13*nr*na)=dIS3R_mdt(:);
dydt(13*nr*na+1:14*nr*na) =dIS4_mdt(:);
dydt(14*nr*na+1:15*nr*na)=dIS4R_mdt(:);

dydt(15*nr*na+1:16*nr*na)=dS_fdt(:);
dydt(16*nr*na+1:17*nr*na)=dIA1_fdt(:);
dydt(17*nr*na+1:18*nr*na)=dIA2_fdt(:);
dydt(18*nr*na+1:19*nr*na)=dIA2R_fdt(:);
dydt(19*nr*na+1:20*nr*na)=dIA3_fdt(:);
dydt(20*nr*na+1:21*nr*na)=dIA3R_fdt(:);
dydt(21*nr*na+1:22*nr*na)=dIA4_fdt(:);
dydt(22*nr*na+1:23*nr*na)=dIA4R_fdt(:);
dydt(23*nr*na+1:24*nr*na)=dIS1_fdt(:);
dydt(24*nr*na+1:25*nr*na)=dIS2_fdt(:);
dydt(25*nr*na+1:26*nr*na)=dIS2R_fdt(:);
dydt(26*nr*na+1:27*nr*na)=dIS3_fdt(:);
dydt(27*nr*na+1:28*nr*na)=dIS3R_fdt(:);
dydt(28*nr*na+1:29*nr*na)=dIS4_fdt(:);
dydt(29*nr*na+1:30*nr*na)=dIS4R_fdt(:);

dydt=dydt';
end
