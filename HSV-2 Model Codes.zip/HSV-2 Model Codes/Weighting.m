function [WeightData] =Weighting(DataLR,m,se,ag,pop)

SampleRepated=zeros(length(DataLR{m,se,ag,pop}(:,1)),1);
for i=1:length(DataLR{m,se,ag,pop}(:,1))
    for j=1:length(DataLR{m,se,ag,pop}(:,1))
        if (j~=i)&&(DataLR{m,se,ag,pop}(j,1)==DataLR{m,se,ag,pop}(i,1)) %(DataLR{m}(1,5)==0)&&
           SampleRepated(i)=max([DataLR{m,se,ag,pop}(i,3) DataLR{m,se,ag,pop}(j,3) SampleRepated(i)]);
        end
    end
end
for i=1:length(DataLR{m,se,ag,pop}(:,1))
    if SampleRepated(i)==0
       SampleRepated(i)= DataLR{m,se,ag,pop}(i,3);
    end
end
WeightData=DataLR{m,se,ag,pop}(:,3)./SampleRepated;