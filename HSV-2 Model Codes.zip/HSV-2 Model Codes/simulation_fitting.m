% Code to visualize the fitting of the model to the data in each region
clearvars;
close all;
clc;

%%Demographic Parameters
%AMRO
resMM(:,1)=[0.0261207954133122;1946.81772633606;118.599541538751;16.4110629955483;1.09490860011076;0.515181604928620;1931.34772058403;105.329882094398];
resFF(:,1)=[0.0287475400714148;1949.42525322778;102.207330010115;19.5355361224265;0.601460757019454;0.995476239856705;1955.00343997857;80.1986285594092];
%AFRO
resMM(:,2)=[0.0353619448124214;1978.59700090851;115.525900027459;13.9945883126358;4686.69070197867;0.149130144239916;1992.23700499082;133.736583479586];
resFF(:,2)=[0.0364720525771215;1979.46342268484;115.280226268682;22.7720870935737;0.375100604553392;2.04141595004822;1978.31611414644;86.8373362610652];
%EMRO
resMM(:,3)=[0.0315662099280342;1966.51654857418;103.998286457569;14.9874071103858;19.9994443096425;0.149048141114245;2153.46322548890;185.527329502280];
resFF(:,3)=[0.0318317213356568;1968.67207734349;115.485186118526;18.7161847648276;0.690300074263781;1.01473586815891;1970.30872255856;104.264102475493];
%EURO
resMM(:,4)=[0.0184161320410699;1921.45699064487;178.140738217763;19.5834978770539;0.696229909053583;3.12081750815939;1845.78664151800;150.555555341066];
resFF(:,4)=[0.0177646236345601;1921.43289385640;163.117036367090;19.0785014448194;0.797827117325151;1.78439621438541;1870.56695093851;128.980453549646];
%SEARO
resMM(:,5)=[0.0296551469516410;1944.90019103475;111.733220976356;13.6802459757634;2925.12429175489;0.232771646704259;1919.39699854759;126.730286951399];
resFF(:,5)=[0.0294629096426427;1944.61605569149;105.954075398161;15.0768910937744;9.03211575593305;0.438381215184227;1914.07625184418;116.028091463275];
%WPRO
resMM(:,6)=[0.0261288889876588;1937.57273633265;99.9430665205198;13.0087965280581;1169.88416527640;0.247968704364275;1947.92415838816;65.1346581876220];
resFF(:,6)=[0.0261027607424591;1937.21987636965;93.4539884726257;16.0043155011080;186.491145969344;0.585821755462767;1955.00003586322;59.3970785786438];

%USA
resMM(:,7)=[0.0191534977138340;1947.69438134523;155.916656867262;16.0001490793720;8528.27270153018;0.507678928529457;1920.96949250443;101.068617778832];
resFF(:,7)=[0.0191634125264944;1949.05379141488;143.571033024922;18.8662282343921;0.906300985864953;0.687729833271473;1955.00216303519;88.4613112720918];

%Fitting parameters
load('Prevalence_Result_fit.mat','Prevalence_Result_fit')
load('Prevalence_Result_fit_Lower.mat','Prevalence_Result_fit_Lower')
load('Prevalence_Result_fit_Upper.mat','Prevalence_Result_fit_Upper')

Prevalence_Result{1}=Prevalence_Result_fit;
Prevalence_Result{2}=Prevalence_Result_fit_Lower;
Prevalence_Result{3}=Prevalence_Result_fit_Upper;

%%Data Extraction
%%Import dataset
%%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, Global 7)

%%Overall prevalence measures
Data=readtable('HSV-2Data_Age.xlsx','Sheet', 2);
tbl =table(Data.Name, Data.WHO_coded, Data.Gender, Data.Index_Age, Data.health, Data.midpoint, Data.prevalence, Data.n, 'VariableNames', {'NameUSA', 'Region', 'Sex', 'Age', 'Study_pop', 'Year','Prevalence','Sample_Size'});

%NHANES data
DataF=xlsread('NHANES_Female.xlsx', 1);
DataFL=xlsread('NHANES_Female.xlsx', 2);
DataFU=xlsread('NHANES_Female.xlsx', 3);

DataM=xlsread('NHANES_Male.xlsx', 1);
DataML=xlsread('NHANES_Male.xlsx', 2);
DataMU=xlsread('NHANES_Male.xlsx', 3);

%All_populations
for m=7:7 %%Over each region

if m~=1    
%%%Total population size male and female
    PoulationSizeM='Malepopulationsize.xlsx';
    PopulationMale= xlsread(PoulationSizeM,m);
    PopulationMale=1000.*PopulationMale;

    PoulationSizeF='Femalepopulationsize.xlsx';
    PopulationFemale= xlsread(PoulationSizeF,m);
    PopulationFemale=1000.*PopulationFemale;    
else
    %%%Total population size male and female
    PoulationSizeM='Malepopulationsize.xlsx';
    PopulationMale1= xlsread(PoulationSizeM,m);
    PopulationMale2= xlsread(PoulationSizeM,7);
    PopulationMale=1000.*(PopulationMale1-PopulationMale2);

    PoulationSizeF='Femalepopulationsize.xlsx';
    PopulationFemale1= xlsread(PoulationSizeF,m);
    PopulationFemale2= xlsread(PoulationSizeF,7);    
    PopulationFemale=1000.*(PopulationFemale1-PopulationFemale2);  
end
%%%Extrting data
for se=1:2 %Women 1 and Men 2
for ag=1:19
for pop=1:3 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==1
Data_All_population=tbl((tbl.NameUSA ~="NHANES")&(tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
elseif m==7
Data_All_population=tbl((tbl.NameUSA =="NHANES")&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
else    
Data_All_population=tbl((tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
end
Data_All_population_YP=table(Data_All_population.Year,Data_All_population.Prevalence,Data_All_population.Sample_Size);
DataAllP{m,se,ag,pop}=table2array(Data_All_population_YP);
DataAllP_Lower{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);
DataAllP_Upper{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);

DataAllP{m,se,ag,pop}(:,4)=Weighting(DataAllP,m,se,ag,pop);
DataAllP_Lower{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);
DataAllP_Upper{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);

for i=1:length(DataAllP{m,se,ag,pop}(:,1))
    [phat,pci] = binofit(DataAllP{m,se,ag,pop}(i,2)/100*DataAllP{m,se,ag,pop}(i,3),DataAllP{m,se,ag,pop}(i,3));
    DataAllP_Lower{m,se,ag,pop}(i,2)=100.*pci(1);
    DataAllP_Upper{m,se,ag,pop}(i,2)=100.*pci(2);
    
    DataAllP_Lower{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
    DataAllP_Upper{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
end
end
end

for ag=1:19
for pop=1:3 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==7
   if pop==1 
       if se==1 
       DataAllP{m,se,ag,pop}=[DataF(:,1) 100.*DataF(:,ag+1) ones(length(DataF(:,ag+1)),1) ones(length(DataF(:,ag+1)),1)];
       DataAllP_Lower{m,se,ag,pop}=[DataFL(:,1) 100.*DataFL(:,ag+1) ones(length(DataFL(:,ag+1)),1) ones(length(DataFL(:,ag+1)),1)];
       DataAllP_Upper{m,se,ag,pop}=[DataFU(:,1) 100.*DataFU(:,ag+1) ones(length(DataFU(:,ag+1)),1) ones(length(DataFU(:,ag+1)),1)];
       else
       DataAllP{m,se,ag,pop}=[DataM(:,1) 100.*DataM(:,ag+1) ones(length(DataM(:,ag+1)),1) ones(length(DataM(:,ag+1)),1)];
       DataAllP_Lower{m,se,ag,pop}=[DataML(:,1) 100.*DataML(:,ag+1) ones(length(DataML(:,ag+1)),1) ones(length(DataML(:,ag+1)),1)];
       DataAllP_Upper{m,se,ag,pop}=[DataMU(:,1) 100.*DataMU(:,ag+1) ones(length(DataMU(:,ag+1)),1) ones(length(DataMU(:,ag+1)),1)];
       end
   end
end
   
DataAllPR{se,ag,pop}=DataAllP{m,se,ag,pop};
DataAllP_LowerR{se,ag,pop}=DataAllP_Lower{m,se,ag,pop};
DataAllP_UpperR{se,ag,pop}=DataAllP_Upper{m,se,ag,pop}; 

% %%%For ploting
% if isempty(DataAllP{m,se,ag,pop}(:,1))==0
% DataAllPAge{m,se,pop}(:,ag,1)=DataAllP{m,se,ag,pop}(:,1);
% DataAllPAge{m,se,pop}(:,ag,2)=DataAllP{m,se,ag,pop}(:,2);
% end

end
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%parameters related to risk
nr=5; %number of risk groups

%parameters related to age groups
na=20; %age interval of five years

n_stage=15;

%the level of risk of exposure dependent by age
a=1:na;
Phi_male=(5./(a.*sqrt(2*pi*(0.3707)^2))).*(exp((-(log(a)-1.792).^2)./(2*(0.3707)^2)));
Phi_female=(8./(a.*sqrt(2*pi*(0.3948)^2))).*(exp((-(log(a)-1.859).^2)./(2*(0.3948)^2)));

%--- power law function in level of risk of exposure
beta_law=2.8;
jj=1:5;
pwlaw=jj.^beta_law;

%%Estimated Parameters for the birth and mortality Male and Female
%Demographique Male
resM=resMM(:,m);
%Demographique female
resF=resFF(:,m);

% Distributing the population 
%PopulationSize=zeros(n_sex,na,nr);%intitialization
RiskGroupPopulationFactorsMales=[0.1307,0.6577,0.0811,0.0358,0.0947];
RiskGroupPopulationFactorsFemales=[0.1736,0.6828,0.0848,0.0299,0.0289];
PopulationSizeMale=PopulationMale(1,2:21)'*RiskGroupPopulationFactorsMales;
PopulationSizeFemale=PopulationFemale(1,2:21)'*RiskGroupPopulationFactorsFemales;

for CI=1:3
    if CI==1    
       [fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1,ProportionGenitalLession2,ProportionGenitalLession3] =TransitionRates(0);
    elseif CI==2
       [fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1,ProportionGenitalLession2,ProportionGenitalLession3] =TransitionRates(-0.3); 
    else
       [fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,ProportionGenitalLession1,ProportionGenitalLession2,ProportionGenitalLession3] =TransitionRates(0.3);
    end
    
%% Estimated Parameters
q=Prevalence_Result{CI}(1,m)*10;
r0=Prevalence_Result{CI}(2,m);

if m==3
%%%Assuming constant rho in case of EMRO
D0=1;
alphaZ= 0;
YearW=0;
else
D0= Prevalence_Result{CI}(3,m);
alphaZ= Prevalence_Result{CI}(4,m);
YearW= Prevalence_Result{CI}(5,m)*10^(4); 
end

init_prev_male=Prevalence_Result{CI}(6,m);
init_prev_female=Prevalence_Result{CI}(7,m);
AnchIR(CI,m)=Prevalence_Result{CI}(8,m);
AnchHR(CI,m)=Prevalence_Result{CI}(9,m);

%% Time Span 
%years: These should be the same as the years used for demographic model
tmin=1750; %beginning
tmax=2050.5; %end year 
% tmax=2500.5; %end year %just for testing
dt=0.5;
tspan=tmin:dt:tmax;

S_m0=zeros(na,nr);
IA1_m0=zeros(na,nr);
IS1_m0=zeros(na,nr);

S_f0=zeros(na,nr);
IA1_f0=zeros(na,nr);
IS1_f0=zeros(na,nr);

Y0=zeros(2*n_stage*na*nr,1);

for a=4:na    
    IA1_m0(a,:)=(1-fs)*init_prev_male*PopulationSizeMale(a,:);
    IS1_m0(a,:)=fs*init_prev_male*PopulationSizeMale(a,:);
    
    IA1_f0(a,:)=(1-fs)*init_prev_female*PopulationSizeFemale(a,:);
    IS1_f0(a,:)=fs*init_prev_female*PopulationSizeFemale(a,:);
end
for a=1:na
    S_m0(a,:)=PopulationSizeMale(a,:)-IA1_m0(a,:)-IS1_m0(a,:);
    S_f0(a,:)=PopulationSizeFemale(a,:)-IA1_f0(a,:)-IS1_f0(a,:);
end

for a=1:na
    Y0(nr*(a-1)+1:nr*a)=S_m0(a,:);
    Y0(100+nr*(a-1)+1:100+nr*a)=IA1_m0(a,:);
    Y0(800+nr*(a-1)+1:800+nr*a)=IS1_m0(a,:);
    
    Y0(1500+nr*(a-1)+1:1500+nr*a)=S_f0(a,:);
    Y0(1600+nr*(a-1)+1:1600+nr*a)=IA1_f0(a,:);
    Y0(2300+nr*(a-1)+1:2300+nr*a)=IS1_f0(a,:);
end
%% Solutions to the model 
tic

[T,Y]=ode15s(@(t,y)HSV2model_Fun(t,y,na,nr,n_stage,fs,fGUD,pwlaw,Phi_male,Phi_female,q,alphaZ,YearW,r0,D0,resM,resF,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A), tspan,Y0);

S_M=zeros(length(T),na);
IA1_M=zeros(length(T),na);
IA2_M=zeros(length(T),na);
IA2R_M=zeros(length(T),na);
IA3_M=zeros(length(T),na);
IA3R_M=zeros(length(T),na);
IA4_M=zeros(length(T),na);
IA4R_M=zeros(length(T),na);
IS1_M=zeros(length(T),na);
IS2_M=zeros(length(T),na);
IS2R_M=zeros(length(T),na);
IS3_M=zeros(length(T),na);
IS3R_M=zeros(length(T),na);
IS4_M=zeros(length(T),na);
IS4R_M=zeros(length(T),na);

S_F=zeros(length(T),na);
IA1_F=zeros(length(T),na);
IA2_F=zeros(length(T),na);
IA2R_F=zeros(length(T),na);
IA3_F=zeros(length(T),na);
IA3R_F=zeros(length(T),na);
IA4_F=zeros(length(T),na);
IA4R_F=zeros(length(T),na);
IS1_F=zeros(length(T),na);
IS2_F=zeros(length(T),na);
IS2R_F=zeros(length(T),na);
IS3_F=zeros(length(T),na);
IS3R_F=zeros(length(T),na);
IS4_F=zeros(length(T),na);
IS4R_F=zeros(length(T),na);

for a=1:na
    S_M(:,a)=sum(Y(:,nr*(a-1)+1:nr*a),2);
    IA1_M(:,a)=sum(Y(:,100+nr*(a-1)+1:100+nr*a),2);
    IA2_M(:,a)=sum(Y(:,200+nr*(a-1)+1:200+nr*a),2);
    IA2R_M(:,a)=sum(Y(:,300+nr*(a-1)+1:300+nr*a),2);
    IA3_M(:,a)=sum(Y(:,400+nr*(a-1)+1:400+nr*a),2);
    IA3R_M(:,a)=sum(Y(:,500+nr*(a-1)+1:500+nr*a),2);
    IA4_M(:,a)=sum(Y(:,600+nr*(a-1)+1:600+nr*a),2);
    IA4R_M(:,a)=sum(Y(:,700+nr*(a-1)+1:700+nr*a),2);
    IS1_M(:,a)=sum(Y(:,800+nr*(a-1)+1:800+nr*a),2);
    IS2_M(:,a)=sum(Y(:,900+nr*(a-1)+1:900+nr*a),2);
    IS2R_M(:,a)=sum(Y(:,1000+nr*(a-1)+1:1000+nr*a),2);
    IS3_M(:,a)=sum(Y(:,1100+nr*(a-1)+1:1100+nr*a),2);
    IS3R_M(:,a)=sum(Y(:,1200+nr*(a-1)+1:1200+nr*a),2);
    IS4_M(:,a)=sum(Y(:,1300+nr*(a-1)+1:1300+nr*a),2);
    IS4R_M(:,a)=sum(Y(:,1400+nr*(a-1)+1:1400+nr*a),2);
    S_F(:,a)=sum(Y(:,1500+nr*(a-1)+1:1500+nr*a),2);
    IA1_F(:,a)=sum(Y(:,1600+nr*(a-1)+1:1600+nr*a),2);
    IA2_F(:,a)=sum(Y(:,1700+nr*(a-1)+1:1700+nr*a),2);
    IA2R_F(:,a)=sum(Y(:,1800+nr*(a-1)+1:1800+nr*a),2);
    IA3_F(:,a)=sum(Y(:,1900+nr*(a-1)+1:1900+nr*a),2);
    IA3R_F(:,a)=sum(Y(:,2000+nr*(a-1)+1:2000+nr*a),2);
    IA4_F(:,a)=sum(Y(:,2100+nr*(a-1)+1:2100+nr*a),2);
    IA4R_F(:,a)=sum(Y(:,2200+nr*(a-1)+1:2200+nr*a),2);
    IS1_F(:,a)=sum(Y(:,2300+nr*(a-1)+1:2300+nr*a),2);
    IS2_F(:,a)=sum(Y(:,2400+nr*(a-1)+1:2400+nr*a),2);
    IS2R_F(:,a)=sum(Y(:,2500+nr*(a-1)+1:2500+nr*a),2);
    IS3_F(:,a)=sum(Y(:,2600+nr*(a-1)+1:2600+nr*a),2);
    IS3R_F(:,a)=sum(Y(:,2700+nr*(a-1)+1:2700+nr*a),2);
    IS4_F(:,a)=sum(Y(:,2800+nr*(a-1)+1:2800+nr*a),2);
    IS4R_F(:,a) =sum(Y(:,2900+nr*(a-1)+1:2900+nr*a),2);
end

% Lambda_m , Lambda_f and Incidence
L_M1=zeros(length(T),na);
L_F1=zeros(length(T),na);
Incidence_Male=zeros(length(T),na);
Incidence_Female=zeros(length(T),na);

for t=1:length(T)
    [dy,L_M1(t,:),L_F1(t,:),Incidence_Male(t,:),Incidence_Female(t,:)]=HSV2model_Fun(T(t),Y(t,:), na,nr,n_stage,fs,fGUD,pwlaw,Phi_male,Phi_female,q,alphaZ,YearW,r0,D0,resM,resF,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A);
end
toc
%% Calculations of Indicators
Infected_Males=IA1_M+IA2_M+IA2R_M+IA3_M+IA3R_M+IA4_M+IA4R_M+IS1_M+IS2_M+IS2R_M+IS3_M+IS3R_M+IS4_M+IS4R_M;
Infected_Females=IA1_F+IA2_F+IA2R_F+IA3_F+IA3R_F+IA4_F+IA4R_F+IS1_F+IS2_F+IS2R_F+IS3_F+IS3R_F+IS4_F+IS4R_F;
Number_Males=S_M+Infected_Males;
Number_Females=S_F+Infected_Females;

Incidence=Incidence_Male+Incidence_Female;
IncidenceRate_Male=L_M1;
IncidenceRate_Female=L_F1;

for t1=1:length(T)
    for a=1:na
        Prevelance_MALE_15_49A{CI,m}(t1,a)=100*(Infected_Males(t1,a))/((Number_Males(t1,a)));
        Prevelance_FEMALE_15_49A{CI,m}(t1,a)=100*(Infected_Females(t1,a))/((Number_Females(t1,a))); 
    end
end

for t1=1:length(T)
    Prevelance_MALE_15_49{CI,m}(t1)=100*sum(Infected_Males(t1,4:10))/(sum(Number_Males(t1,4:10)));
    Prevelance_FEMALE_15_49{CI,m}(t1)=100*sum(Infected_Females(t1,4:10))/(sum(Number_Females(t1,4:10))); 
    Prevelance_15_49{CI,m}(t1)=100*sum(Infected_Males(t1,4:10)+Infected_Females(t1,4:10))/sum(Number_Males(t1,4:10)+Number_Females(t1,4:10));
    
    Incidence_Male_15_49{CI,m}(t1)=sum(Incidence_Male(t1,4:10));
    Incidence_Female_15_49{CI,m}(t1)=sum(Incidence_Female(t1,4:10));
    Incidence_15_49{CI,m}(t1)=sum(Incidence(t1,4:10));
    
    IncidenceRate_MALE_15_49{CI,m}(t1)=1000.*sum(Incidence_Male(t1,4:10))/sum(S_M(t1,4:10));
    IncidenceRate_FEMALE_15_49{CI,m}(t1)=1000.*sum(Incidence_Female(t1,4:10))/sum(S_F(t1,4:10)); 
    IncidenceRate_15_49{CI,m}(t1)=1000.*sum(Incidence_Female(t1,4:10)+Incidence_Male(t1,4:10))/sum(S_F(t1,4:10)+S_M(t1,4:10)); 

    NumberGUD1_Male(t1)=sum(IS1_M(t1,4:10)+IS2_M(t1,4:10)+IS2R_M(t1,4:10));
    NumberGUD1_Female(t1)=sum(IS1_F(t1,4:10)+IS2_F(t1,4:10)+IS2R_F(t1,4:10));
    ProportionGUD1{CI,m}(t1)=100.*(NumberGUD1_Male(t1)+NumberGUD1_Female(t1))/sum(Infected_Males(t1,4:10)+Infected_Females(t1,4:10));

    NumberGUD2_Male(t1)=sum(IS3_M(t1,4:10)+IS3R_M(t1,4:10));
    NumberGUD2_Female(t1)=sum(IS3_F(t1,4:10)+IS3R_F(t1,4:10));
    ProportionGUD2{CI,m}(t1)=100.*(NumberGUD2_Male(t1)+NumberGUD2_Female(t1))/sum(Infected_Males(t1,4:10)+Infected_Females(t1,4:10));

    NumberGUD3_Male(t1)=sum(IS4_M(t1,4:10)+IS4R_M(t1,4:10));
    NumberGUD3_Female(t1)=sum(IS4_F(t1,4:10)+IS4R_F(t1,4:10));
    ProportionGUD3{CI,m}(t1)=100.*(NumberGUD3_Male(t1)+NumberGUD3_Female(t1))/sum(Infected_Males(t1,4:10)+Infected_Females(t1,4:10));
end
end

dtt=1980:dt:2050;

fname1=["AMRO (without USA)","AFRO","EMRO","EURO","SEARO","WPRO","USA"];
fname2=["15-19","20-24","25-29","30-34","35-39","40-44","45-49","50-54","55-59","60-64","65-69","70-74"];
%%%Fitting each measures
%%General populations

% subplot(4,3,ro)
% ax = gca;
% ax.XTickLabel={'20-24','45-49','70-74','95-99'};

%General population
figure
for ag=4:15
subplot(4,3,ag-3)
hold on
p1=plot(1970:dt:2020,Prevelance_FEMALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
% p1=plot(1970:dt:2020,Prevelance_FEMALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
p2=plot(DataAllP{m,1,ag,1}(:,1),DataAllP{m,1,ag,1}(:,2),'*')
xlabel('Year','FontSize',7)
ylabel({'HSV-2 seroprevalence among','women (%)'},'FontSize',7)
ylim([0 100])
xlim([1970 2020])
title(fname2(ag-3),'fontweight','bold')
end
legend([p2,p1],{'Data','Model prediction'})

figure
for ag=4:15
subplot(4,3,ag-3)
hold on
p1=plot(1970:dt:2020,Prevelance_MALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
p2=plot(DataAllP{m,2,ag,1}(:,1),DataAllP{m,2,ag,1}(:,2),'*')
xlabel('Years','FontSize',7)
ylabel({'HSV-2 seroprevalence among','men (%)'},'FontSize',7)
ylim([0 100])
xlim([1970 2020])
title(fname2(ag-3),'fontweight','bold')
end


%Intermediate
figure
for ag=4:15
subplot(4,3,ag-3)
hold on
p1=plot(1970:dt:2020,Prevelance_FEMALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
p2=plot(DataAllP{m,1,ag,2}(:,1),AnchIR(1,m)*DataAllP{m,1,ag,2}(:,2),'*')
xlabel('Years','FontSize',7)
ylabel({'HSV-2 seroprevalence among','women (%)'},'FontSize',7)
ylim([0 100])
xlim([1970 2020])
end

figure
for ag=4:15
subplot(4,3,ag-3)
hold on
p1=plot(1970:dt:2020,Prevelance_MALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
p2=plot(DataAllP{m,2,ag,2}(:,1),AnchIR(1,m)*DataAllP{m,2,ag,2}(:,2),'*')
xlabel('Years','FontSize',7)
ylabel({'HSV-2 seroprevalence among','men (%)'},'FontSize',7)
ylim([0 100])
xlim([1970 2020])
end

%High risk
figure
for ag=4:15
subplot(4,3,ag-3)
hold on
p1=plot(1970:dt:2020,Prevelance_FEMALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
p2=plot(DataAllP{m,1,ag,3}(:,1),AnchHR(1,m)*DataAllP{m,1,ag,3}(:,2),'*')
xlabel('Years','FontSize',7)
ylabel({'HSV-2 seroprevalence among','women (%)'},'FontSize',7)
ylim([0 100])
xlim([1970 2020])
end

figure
for ag=4:15
subplot(4,3,ag-3)
hold on
p1=plot(1970:dt:2020,Prevelance_MALE_15_49A{1,m}((1970-tmin)*2+1:(2020-tmin)*2+1,ag),'LineWidth',2)
p2=plot(DataAllP{m,2,ag,3}(:,1),AnchHR(1,m)*DataAllP{m,2,ag,3}(:,2),'*')
xlabel('Years','FontSize',7)
ylabel({'HSV-2 seroprevalence among','men (%)'},'FontSize',7)
ylim([0 100])
xlim([1970 2020])
end
end



%%%These are only for the USA
NHANES_F=xlsread('NHANES_Female_All.xlsx', 1);
NHANES_M=xlsread('NHANES_Male_All.xlsx', 1);

figure
for m=7:7
    mm=m-6;
subplot(2,1,2*mm-1)
hold on
p1=plot(dtt,Prevelance_FEMALE_15_49{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'m','LineWidth',2)
plot(dtt,Prevelance_FEMALE_15_49{2,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'--m','LineWidth',2)
plot(dtt,Prevelance_FEMALE_15_49{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'--m','LineWidth',2)
p2=plot(NHANES_F(:,1),NHANES_F(:,2),'*m')
ylabel({'HSV-2 seroprevalence among';'women aged 15-49 years';'(%)'})
xlabel('Year')
ylim([0 100])
xlim([1980 2050])
legend([p2,p1],{'Seroprevalence data for women in the general populations','Model prediction for women'})
%title(fname1(m),'fontweight','bold')

subplot(2,1,2*mm)
hold on
p1=plot(dtt,Prevelance_MALE_15_49{1,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'b','LineWidth',2)
plot(dtt,Prevelance_MALE_15_49{2,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'--b','LineWidth',2)
plot(dtt,Prevelance_MALE_15_49{3,m}((1980-tmin)*2+1:(2050-tmin)*2+1),'--b','LineWidth',2)
p2=plot(NHANES_M(:,1),NHANES_M(:,2),'*m')
ylim([0 100])
ylabel({'HSV-2 seroprevalence among';'men aged 15-49 years';'(%)'})
xlabel('Year')
xlim([1980 2050])
legend([p2,p1],{'Seroprevalence data for men in the general populations','Model prediction for men'})
%title(fname1(m),'fontweight','bold')
end