function [CI_lower,CI_upper] =CI_Sampling_Triangular(mean_value,lower_bound,upper_bound)

        % Number of samples
        n = 1000;

        % Generate uniform random numbers
        sobol_seq = sobolset(1); % Generate a 1-dimensional Sobol sequence
        U = net(sobol_seq, n);   % Generate 'n' points between 0 and 1

        % Compute threshold
        F = (mean_value - lower_bound) / (upper_bound - lower_bound);

        % Apply inverse transform sampling
        samples = zeros(n,1);
        for i = 1:n
            if U(i) <= F
                samples(i) = lower_bound + sqrt(U(i) * (mean_value - lower_bound) * (upper_bound - lower_bound));
            else
                samples(i) = upper_bound - sqrt((1 - U(i)) * (upper_bound - lower_bound) * (upper_bound - mean_value));
            end
        end
        
%         SamplesSorted=sort(samples);
%         CI_lower =SamplesSorted(round(0.025*n));
%         CI_upper =SamplesSorted(round(0.975*n));

        CI_lower = quantile(samples, 0.025);
        CI_upper = quantile(samples, 0.975);
        
%         % Calculate sample mean and standard deviation
%         sample_mean = mean(samples);
%         sample_std = std(samples);
% 
%         % Calculate standard error
%         SE = sample_std / sqrt(n);
% 
%         % Calculate 95% Confidence Interval (using Z = 1.96)
%         Z = 1.96;
%         CI_lower = mean_value - Z * SE;
%         CI_upper = mean_value + Z * SE;
end
        

        