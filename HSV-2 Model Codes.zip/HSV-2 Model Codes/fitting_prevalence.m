%%%Fitting code
clearvars;
close all;
clear all
clc;

%%Demographic Parameters estimated using the demographic model
%AMRO
resMM(:,1)=[0.0261207954133122;1946.81772633606;118.599541538751;16.4110629955483;1.09490860011076;0.515181604928620;1931.34772058403;105.329882094398];
resFF(:,1)=[0.0287475400714148;1949.42525322778;102.207330010115;19.5355361224265;0.601460757019454;0.995476239856705;1955.00343997857;80.1986285594092];
%AFRO
resMM(:,2)=[0.0353619448124214;1978.59700090851;115.525900027459;13.9945883126358;4686.69070197867;0.149130144239916;1992.23700499082;133.736583479586];
resFF(:,2)=[0.0364720525771215;1979.46342268484;115.280226268682;22.7720870935737;0.375100604553392;2.04141595004822;1978.31611414644;86.8373362610652];
%EMRO
resMM(:,3)=[0.0315662099280342;1966.51654857418;103.998286457569;14.9874071103858;19.9994443096425;0.149048141114245;2153.46322548890;185.527329502280];
resFF(:,3)=[0.0318317213356568;1968.67207734349;115.485186118526;18.7161847648276;0.690300074263781;1.01473586815891;1970.30872255856;104.264102475493];
%EURO
resMM(:,4)=[0.0184161320410699;1921.45699064487;178.140738217763;19.5834978770539;0.696229909053583;3.12081750815939;1845.78664151800;150.555555341066];
resFF(:,4)=[0.0177646236345601;1921.43289385640;163.117036367090;19.0785014448194;0.797827117325151;1.78439621438541;1870.56695093851;128.980453549646];
%SEARO
resMM(:,5)=[0.0296551469516410;1944.90019103475;111.733220976356;13.6802459757634;2925.12429175489;0.232771646704259;1919.39699854759;126.730286951399];
resFF(:,5)=[0.0294629096426427;1944.61605569149;105.954075398161;15.0768910937744;9.03211575593305;0.438381215184227;1914.07625184418;116.028091463275];
%WPRO
resMM(:,6)=[0.0261288889876588;1937.57273633265;99.9430665205198;13.0087965280581;1169.88416527640;0.247968704364275;1947.92415838816;65.1346581876220];
resFF(:,6)=[0.0261027607424591;1937.21987636965;93.4539884726257;16.0043155011080;186.491145969344;0.585821755462767;1955.00003586322;59.3970785786438];
%USA
resMM(:,7)=[0.0191534977138340;1947.69438134523;155.916656867262;16.0001490793720;8528.27270153018;0.507678928529457;1920.96949250443;101.068617778832];
resFF(:,7)=[0.0191634125264944;1949.05379141488;143.571033024922;18.8662282343921;0.906300985864953;0.687729833271473;1955.00216303519;88.4613112720918];

% Parameters guesses
load('Prevalence_Result_fit.mat','Prevalence_Result_fit')
load('Prevalence_Result_fit_Lower.mat','Prevalence_Result_fit_Lower')
load('Prevalence_Result_fit_Upper.mat','Prevalence_Result_fit_Upper')

Prevalence_Result_fit_Guess{1}=Prevalence_Result_fit;
Prevalence_Result_fit_Guess{2}=Prevalence_Result_fit_Lower;
Prevalence_Result_fit_Guess{3}=Prevalence_Result_fit_Upper;

%%Data Extraction
%%Import dataset
%%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, USA 7)

%%Overall prevalence measures
Data=readtable('HSV-2Data_Age.xlsx','Sheet', 2);
tbl =table(Data.Name, Data.WHO_coded, Data.Gender, Data.Index_Age, Data.health, Data.midpoint, Data.prevalence, Data.n, 'VariableNames', {'NameUSA', 'Region', 'Sex', 'Age', 'Study_pop', 'Year','Prevalence','Sample_Size'});

%NHANES data
DataF=xlsread('NHANES_Female.xlsx', 1);
DataFL=xlsread('NHANES_Female.xlsx', 2);
DataFU=xlsread('NHANES_Female.xlsx', 3);

DataM=xlsread('NHANES_Male.xlsx', 1);
DataML=xlsread('NHANES_Male.xlsx', 2);
DataMU=xlsread('NHANES_Male.xlsx', 3);

%%%each WHO region (AMRO 1, AFRO 2, EMRO 3, EURO 4, SEARO 5, WPRO 6, USA 7)

%%%Prevalence years range in the different WHO regions
LowerYear=[1979,1989,1991,1969,1991.5,1973,1991];
UpperYear=[2018,2017.5,2018.5,2018.5,2014.5,2017.5,2015.5];

%%%Average Decline based on the meta analyses (not used in the fitting)
declineData=[0.98 0.98 0.97 0.99 0.97 0.99 0];
declineDataLower=[0.97 0.96 0.94 0.98 0.94 0.97 0];
declineDataUpper=[0.99 0.99 1.01 1.00 0.99 1.00 0];

%%%Pooled prevalence data <2000 for Female and Male (not used in the fitting)
PooledPrevalence(:,1)=[26.4 43.3 5.8 14.6 17.3 12.5 0];
PooledPrevalenceL(:,1)=[25.5 42.5 0.0 13.0 11.6 9.0 0];
PooledPrevalenceU(:,1)=[27.4 44.1 21.7 16.3 23.9 16.4 0];

PooledPrevalence(:,2)=[15.1 24.6 0.7 8.0 10.9365 12.2 0];
PooledPrevalenceL(:,2)=[13.9 23.0 0.0 6.7 6.4827 7.0 0];
PooledPrevalenceU(:,2)=[16.4 25.4 4.1 9.5 20.0889 20.1 0];

%%%Model fitting to the data in each region
for m=1:7
%%%Demographic data
if m~=1    
%%%Total population size male and female
    PoulationSizeM='Malepopulationsize.xlsx';
    PopulationMale= xlsread(PoulationSizeM,m);
    PopulationMale=1000.*PopulationMale;

    PoulationSizeF='Femalepopulationsize.xlsx';
    PopulationFemale= xlsread(PoulationSizeF,m);
    PopulationFemale=1000.*PopulationFemale;    
else
    %%%Total population size male and female
    PoulationSizeM='Malepopulationsize.xlsx';
    PopulationMale1= xlsread(PoulationSizeM,m);
    PopulationMale2= xlsread(PoulationSizeM,7);
    PopulationMale=1000.*(PopulationMale1-PopulationMale2);

    PoulationSizeF='Femalepopulationsize.xlsx';
    PopulationFemale1= xlsread(PoulationSizeF,m);
    PopulationFemale2= xlsread(PoulationSizeF,7);    
    PopulationFemale=1000.*(PopulationFemale1-PopulationFemale2);  
end
%%%Extrting data
for se=1:2 %Women 1 and Men 2
for ag=1:19
for pop=1:3 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==1
Data_All_population=tbl((tbl.NameUSA ~="NHANES")&(tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
elseif m==7
Data_All_population=tbl((tbl.NameUSA =="NHANES")&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
else    
Data_All_population=tbl((tbl.Region ==m)&(tbl.Sex ==se)&(tbl.Age ==ag)&(tbl.Study_pop ==pop)&(tbl.Year ~=0)&(tbl.Prevalence ~=0),:);
end
Data_All_population_YP=table(Data_All_population.Year,Data_All_population.Prevalence,Data_All_population.Sample_Size);
DataAllP{m,se,ag,pop}=table2array(Data_All_population_YP);
DataAllP_Lower{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);
DataAllP_Upper{m,se,ag,pop}(:,1)=DataAllP{m,se,ag,pop}(:,1);

DataAllP{m,se,ag,pop}(:,4)=Weighting(DataAllP,m,se,ag,pop);
DataAllP_Lower{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);
DataAllP_Upper{m,se,ag,pop}(:,4)=DataAllP{m,se,ag,pop}(:,4);

for i=1:length(DataAllP{m,se,ag,pop}(:,1))
    [phat,pci] = binofit(DataAllP{m,se,ag,pop}(i,2)/100*DataAllP{m,se,ag,pop}(i,3),DataAllP{m,se,ag,pop}(i,3));
    DataAllP_Lower{m,se,ag,pop}(i,2)=100.*pci(1);
    DataAllP_Upper{m,se,ag,pop}(i,2)=100.*pci(2);
    
    DataAllP_Lower{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
    DataAllP_Upper{m,se,ag,pop}(i,3:4)=DataAllP{m,se,ag,pop}(i,3:4);
end
end
end

for ag=1:19
for pop=1:3 %General population 1, Intermediate risk populations 2, and Higher RP 3
if m==7
   if pop==1 
       if se==1 
       DataAllP{m,se,ag,pop}=[DataF(:,1) 100.*DataF(:,ag+1) ones(length(DataF(:,ag+1)),1) ones(length(DataF(:,ag+1)),1)];
       DataAllP_Lower{m,se,ag,pop}=[DataFL(:,1) 100.*DataFL(:,ag+1) ones(length(DataFL(:,ag+1)),1) ones(length(DataFL(:,ag+1)),1)];
       DataAllP_Upper{m,se,ag,pop}=[DataFU(:,1) 100.*DataFU(:,ag+1) ones(length(DataFU(:,ag+1)),1) ones(length(DataFU(:,ag+1)),1)];
       else
       DataAllP{m,se,ag,pop}=[DataM(:,1) 100.*DataM(:,ag+1) ones(length(DataM(:,ag+1)),1) ones(length(DataM(:,ag+1)),1)];
       DataAllP_Lower{m,se,ag,pop}=[DataML(:,1) 100.*DataML(:,ag+1) ones(length(DataML(:,ag+1)),1) ones(length(DataML(:,ag+1)),1)];
       DataAllP_Upper{m,se,ag,pop}=[DataMU(:,1) 100.*DataMU(:,ag+1) ones(length(DataMU(:,ag+1)),1) ones(length(DataMU(:,ag+1)),1)];
       end
   end
end
   
DataAllPR{se,ag,pop}=DataAllP{m,se,ag,pop};
DataAllP_LowerR{se,ag,pop}=DataAllP_Lower{m,se,ag,pop};
DataAllP_UpperR{se,ag,pop}=DataAllP_Upper{m,se,ag,pop};  
end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%years: These should be the same as the years used for demographic model
tmin=1750; %beginning
tmax=2020.5; %end year 

%parameters related to risk
nr=5; %number of risk groups

%parameters related to age groups
na=20; %age interval of five years

n_stage=15;

%Fraction of Symptomatic
fs=0.374;
%%Fraction of individuals with GUD recurrences due to HSV-2 following a documented first episode
fGUD=0.89;
%Symptomatic
shed_freqS=0.201;
cycle_freqS=17.9;
length_dur_primary=20.5;
% duration of latency from latent to reactivation v2
v2S=365*(1-shed_freqS)/cycle_freqS;
% duration of reactivation v3
v3S=365*shed_freqS/cycle_freqS;
%The progression rates from one stage to other per year is:
pi1S=365*(1/length_dur_primary);  %per year
pi2S=365*(1/v2S);
pi3S=365*(1/v3S);

%Asymptomatic
shed_freqA=0.102;
cycle_freqA=12.5;
length_dur_primary=20.5;
% duration of latency from latent to reactivation v2
v2A=365*(1-shed_freqA)/cycle_freqA;
% duration of reactivation v3
v3A=365*shed_freqA/cycle_freqA;
%The progression rates from one stage to other per year is:
pi1A=365*(1/length_dur_primary);  %per year
pi2A=365*(1/v2A);
pi3A=365*(1/v3A);

%the level of risk of exposure dependent by age
a=1:na;
Phi_male=(5./(a.*sqrt(2*pi*(0.3707)^2))).*(exp((-(log(a)-1.792).^2)./(2*(0.3707)^2)));
Phi_female=(8./(a.*sqrt(2*pi*(0.3948)^2))).*(exp((-(log(a)-1.859).^2)./(2*(0.3948)^2)));

%--- power law function in level of risk of exposure
beta_law=2.8;
jj=1:5;
pwlaw=jj.^beta_law;

%%Estimated Parameters for the birth and mortality Male and Female
%Demographique Male
resM=resMM(:,m);
%Demographique female
resF=resFF(:,m);

% Distributing the population 
%PopulationSize=zeros(n_sex,na,nr);%intitialization
RiskGroupPopulationFactorsMales=[0.1307,0.6577,0.0811,0.0358,0.0947];
RiskGroupPopulationFactorsFemales=[0.1736,0.6828,0.0848,0.0299,0.0289];
PopulationSizeMale=PopulationMale(1,2:21)'*RiskGroupPopulationFactorsMales;
PopulationSizeFemale=PopulationFemale(1,2:21)'*RiskGroupPopulationFactorsFemales;

%%%Parameters to estimate
%q_force
vector_fit(1)=Prevalence_Result_fit_Guess{1}(1,m);
lb(1)=0.20;
ub(1)=0.99;

%ro
vector_fit(2)=Prevalence_Result_fit_Guess{1}(2,m);
lb(2)=0.00001;
ub(2)=0.9;

%D0
vector_fit(3)=Prevalence_Result_fit_Guess{1}(3,m);
lb(3)=25;
ub(3)=200;

%alphaZ 
vector_fit(4)=Prevalence_Result_fit_Guess{1}(4,m);
lb(4)=0.01;
ub(4)=0.9;

%YearW
vector_fit(5)=Prevalence_Result_fit_Guess{1}(5,m);
lb(5)=0.1970;
ub(5)=0.2010;

% init prev
vector_fit(6)=Prevalence_Result_fit_Guess{1}(6,m);
lb(6)=0.0001;
ub(6)=0.7;%1;

vector_fit(7)=Prevalence_Result_fit_Guess{1}(7,m);
lb(7)=0.0001;
ub(7)=0.7;%1;

%Anchoring parameters for Intermediate Risk populations
vector_fit(8)=Prevalence_Result_fit_Guess{1}(8,m);
lb(8)=0.0001;
ub(8)=100;

%Anchoring parameters for High Risk populations
vector_fit(9)=Prevalence_Result_fit_Guess{1}(9,m);
lb(9)=0.0001;
ub(9)=100;

options=optimset('Display','iter','TolFun',1e-1,'MaxIter',100,'MaxFunEvals',150);
tic
Prevalence_Result_fit(:,m)=fminsearchbnd(@mainHSV2_fitting,vector_fit,lb,ub,options,tmin,tmax,na,nr,n_stage,fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,pwlaw,Phi_male,Phi_female,resM,resF,PopulationSizeMale,PopulationSizeFemale,DataAllPR,PooledPrevalence(m,:),declineData(m),LowerYear(m),UpperYear(m),m,1)
toc


% %%%%%%%%%%%%Lower and Upper bound%%%%%%%%%%%%estimates%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Lower bound%%%%%%%%%%%%estimates%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%q_force
vector_fit(1)=Prevalence_Result_fit_Guess{2}(1,m);
lb(1)=0.20;
ub(1)=0.99;

%ro
vector_fit(2)=Prevalence_Result_fit_Guess{2}(2,m);
lb(2)=0.00001;
ub(2)=0.9;

%D0
vector_fit(3)=Prevalence_Result_fit(3,m);
lb(3)=Prevalence_Result_fit(3,m);
ub(3)=Prevalence_Result_fit(3,m);

%alphaZ 
vector_fit(4)=Prevalence_Result_fit(4,m);
lb(4)=Prevalence_Result_fit(4,m);
ub(4)=Prevalence_Result_fit(4,m);

%YearW
vector_fit(5)=Prevalence_Result_fit(5,m);
lb(5)=Prevalence_Result_fit(5,m);
ub(5)=Prevalence_Result_fit(5,m);

% init prev
vector_fit(6)=Prevalence_Result_fit(6,m);
lb(6)=Prevalence_Result_fit(6,m);
ub(6)=Prevalence_Result_fit(6,m);

vector_fit(7)=Prevalence_Result_fit(7,m);
lb(7)=Prevalence_Result_fit(7,m);
ub(7)=Prevalence_Result_fit(7,m);

%Anchoring parameters for IR
vector_fit(8)=Prevalence_Result_fit_Guess{2}(8,m);
lb(8)=0.0001;
ub(8)=100;

%Anchoring parameters for HR
vector_fit(9)=Prevalence_Result_fit_Guess{2}(9,m);
lb(9)=0.0001;
ub(9)=100;


options=optimset('Display','iter','TolFun',1e-1,'MaxIter',75,'MaxFunEvals',100);


tic
%Fraction of Symptomatic
fs=0.374*(1-0.3);
%%Fraction of individuals with GUD recurrences due to HSV-2 following a documented first episode
fGUD=0.89*(1-0.3);
%Symptomatic
shed_freqS=0.201*(1-0.3);
cycle_freqS=17.9*(1-0.3);
length_dur_primary=20.5*(1-0.3);
% duration of latency from latent to reactivation v2
v2S=365*(1-shed_freqS)/cycle_freqS;
% duration of reactivation v3
v3S=365*shed_freqS/cycle_freqS;
%The progression rates from one stage to other per year is:
pi1S=365*(1/length_dur_primary);  %per year
pi2S=365*(1/v2S);
pi3S=365*(1/v3S);

%Asymptomatic
shed_freqA=0.102*(1-0.3);
cycle_freqA=12.5*(1-0.3);
length_dur_primary=20.5;
% duration of latency from latent to reactivation v2
v2A=365*(1-shed_freqA)/cycle_freqA;
% duration of reactivation v3
v3A=365*shed_freqA/cycle_freqA;
%The progression rates from one stage to other per year is:
pi1A=365*(1/length_dur_primary);  %per year
pi2A=365*(1/v2A);
pi3A=365*(1/v3A);
Prevalence_Result_fit_Lower(:,m)=fminsearchbnd(@mainHSV2_fitting,vector_fit,lb,ub,options,tmin,tmax,na,nr,n_stage,fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,pwlaw,Phi_male,Phi_female,resM,resF,PopulationSizeMale,PopulationSizeFemale,DataAllP_LowerR,PooledPrevalenceL(m,:),declineDataLower(m),LowerYear(m),UpperYear(m),m,2)
toc


%%%%%%%%%%%%Upper bound%%%%%%%%%%%%estimates%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%q_force
vector_fit(1)=Prevalence_Result_fit_Guess{3}(1,m);
lb(1)=0.20;
ub(1)=0.99;

%ro
vector_fit(2)=Prevalence_Result_fit_Guess{3}(2,m);
lb(2)=0.00001;
ub(2)=0.9;

%D0
vector_fit(3)=Prevalence_Result_fit(3,m);
lb(3)=Prevalence_Result_fit(3,m);
ub(3)=Prevalence_Result_fit(3,m);

%alphaZ 
vector_fit(4)=Prevalence_Result_fit(4,m);
lb(4)=Prevalence_Result_fit(4,m);
ub(4)=Prevalence_Result_fit(4,m);

%YearW
vector_fit(5)=Prevalence_Result_fit(5,m);
lb(5)=Prevalence_Result_fit(5,m);
ub(5)=Prevalence_Result_fit(5,m);

% init prev
vector_fit(6)=Prevalence_Result_fit(6,m);
lb(6)=Prevalence_Result_fit(6,m);
ub(6)=Prevalence_Result_fit(6,m);

vector_fit(7)=Prevalence_Result_fit(7,m);
lb(7)=Prevalence_Result_fit(7,m);
ub(7)=Prevalence_Result_fit(7,m);

%Anchoring parameters for IR
vector_fit(8)=Prevalence_Result_fit_Guess{3}(8,m);
lb(8)=0.0001;
ub(8)=100;

%Anchoring parameters for HR
vector_fit(9)=Prevalence_Result_fit_Guess{3}(9,m);
lb(9)=0.0001;
ub(9)=100;

tic
%Fraction of Symptomatic
fs=0.374*(1+0.3);
%%Fraction of individuals with GUD recurrences due to HSV-2 following a documented first episode
fGUD=1;%0.89*(1+0.3);
%Symptomatic
shed_freqS=0.201*(1+0.3);
cycle_freqS=17.9*(1+0.3);
length_dur_primary=20.5*(1+0.3);
% duration of latency from latent to reactivation v2
v2S=365*(1-shed_freqS)/cycle_freqS;
% duration of reactivation v3
v3S=365*shed_freqS/cycle_freqS;
%The progression rates from one stage to other per year is:
pi1S=365*(1/length_dur_primary);  %per year
pi2S=365*(1/v2S);
pi3S=365*(1/v3S);

%Asymptomatic
shed_freqA=0.102*(1+0.3);
cycle_freqA=12.5*(1+0.3);
length_dur_primary=20.5*(1+0.3);
% duration of latency from latent to reactivation v2
v2A=365*(1-shed_freqA)/cycle_freqA;
% duration of reactivation v3
v3A=365*shed_freqA/cycle_freqA;
%The progression rates from one stage to other per year is:
pi1A=365*(1/length_dur_primary);  %per year
pi2A=365*(1/v2A);
pi3A=365*(1/v3A);
Prevalence_Result_fit_Upper(:,m)=fminsearchbnd(@mainHSV2_fitting,vector_fit,lb,ub,options,tmin,tmax,na,nr,n_stage,fs,fGUD,pi1S,pi2S,pi3S,pi1A,pi2A,pi3A,pwlaw,Phi_male,Phi_female,resM,resF,PopulationSizeMale,PopulationSizeFemale,DataAllP_UpperR,PooledPrevalenceU(m,:),declineDataUpper(m),LowerYear(m),UpperYear(m),m,3)
toc

end
save('Prevalence_Result_fit.mat','Prevalence_Result_fit')

save('Prevalence_Result_fit_Lower.mat','Prevalence_Result_fit_Lower')
 
save('Prevalence_Result_fit_Upper.mat','Prevalence_Result_fit_Upper')






